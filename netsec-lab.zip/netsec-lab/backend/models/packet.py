from sqlalchemy import Column, Integer, String, Float, DateTime, Text
from sqlalchemy.sql import func
from backend.database import Base


class Packet(Base):
    __tablename__ = "packets"

    id          = Column(Integer, primary_key=True, index=True)
    timestamp   = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    src_ip      = Column(String(45), index=True)
    dst_ip      = Column(String(45), index=True)
    src_port    = Column(Integer, nullable=True)
    dst_port    = Column(Integer, nullable=True)
    protocol    = Column(String(16), index=True)
    length      = Column(Integer)
    ttl         = Column(Integer, nullable=True)
    flags       = Column(String(32), nullable=True)
    payload_len = Column(Integer, default=0)
    summary     = Column(Text, nullable=True)
    interface   = Column(String(32), nullable=True)
    geo_src     = Column(String(64), nullable=True)
    geo_dst     = Column(String(64), nullable=True)

    def to_dict(self):
        return {
            "id":          self.id,
            "timestamp":   self.timestamp.isoformat() if self.timestamp else None,
            "src_ip":      self.src_ip,
            "dst_ip":      self.dst_ip,
            "src_port":    self.src_port,
            "dst_port":    self.dst_port,
            "protocol":    self.protocol,
            "length":      self.length,
            "ttl":         self.ttl,
            "flags":       self.flags,
            "payload_len": self.payload_len,
            "summary":     self.summary,
            "interface":   self.interface,
            "geo_src":     self.geo_src,
            "geo_dst":     self.geo_dst,
        }
