from sqlalchemy import Column, Integer, String, DateTime, Text, JSON
from sqlalchemy.sql import func
from backend.database import Base


class Alert(Base):
    __tablename__ = "alerts"

    id          = Column(Integer, primary_key=True, index=True)
    timestamp   = Column(DateTime(timezone=True), server_default=func.now(), index=True)
    event_type  = Column(String(32), index=True)
    severity    = Column(Integer, nullable=True)
    signature   = Column(String(256), nullable=True, index=True)
    sig_id      = Column(Integer, nullable=True)
    category    = Column(String(128), nullable=True)
    src_ip      = Column(String(45), index=True)
    dst_ip      = Column(String(45), index=True)
    src_port    = Column(Integer, nullable=True)
    dst_port    = Column(Integer, nullable=True)
    protocol    = Column(String(16), nullable=True)
    action      = Column(String(16), nullable=True)
    flow_id     = Column(String(32), nullable=True)
    http_host   = Column(String(256), nullable=True)
    http_uri    = Column(Text, nullable=True)
    dns_query   = Column(String(256), nullable=True)
    tls_sni     = Column(String(256), nullable=True)
    raw         = Column(JSON, nullable=True)

    def to_dict(self):
        return {
            "id":         self.id,
            "timestamp":  self.timestamp.isoformat() if self.timestamp else None,
            "event_type": self.event_type,
            "severity":   self.severity,
            "signature":  self.signature,
            "sig_id":     self.sig_id,
            "category":   self.category,
            "src_ip":     self.src_ip,
            "dst_ip":     self.dst_ip,
            "src_port":   self.src_port,
            "dst_port":   self.dst_port,
            "protocol":   self.protocol,
            "action":     self.action,
            "flow_id":    self.flow_id,
            "http_host":  self.http_host,
            "http_uri":   self.http_uri,
            "dns_query":  self.dns_query,
            "tls_sni":    self.tls_sni,
        }
