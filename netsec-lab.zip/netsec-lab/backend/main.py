"""
NetSec Lab — FastAPI application entry point.
"""
from __future__ import annotations

import asyncio
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from backend.config import settings
from backend.database import init_db
from backend.routers.capture import router as capture_router
from backend.routers.alerts import router as alerts_router
from backend.routers.analysis import router as analysis_router
from backend.routers.ws import router as ws_router, broadcast_loop


@asynccontextmanager
async def lifespan(app: FastAPI):
    # startup
    await init_db()
    task = asyncio.create_task(broadcast_loop())
    yield
    # shutdown
    task.cancel()
    try:
        await task
    except asyncio.CancelledError:
        pass


app = FastAPI(
    title=settings.APP_NAME,
    version=settings.APP_VERSION,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(capture_router)
app.include_router(alerts_router)
app.include_router(analysis_router)
app.include_router(ws_router)


@app.get("/")
async def root():
    return {"name": settings.APP_NAME, "version": settings.APP_VERSION, "status": "ok"}


@app.get("/health")
async def health():
    return {"status": "ok"}
