"""
/analysis/* endpoints
- GET /analysis/stats        live in-memory snapshot
- GET /analysis/timeseries   per-second pps or mbps history
- GET /analysis/protocols    protocol breakdown
- GET /analysis/top-talkers  top source IPs by packet count
- GET /analysis/dns          top DNS queries seen
- GET /analysis/http         top HTTP hosts seen
"""
from __future__ import annotations

from fastapi import APIRouter, Query
from backend.services.stats_service import stats_service

router = APIRouter(prefix="/analysis", tags=["analysis"])


@router.get("/stats")
async def get_stats():
    return stats_service.snapshot()


@router.get("/timeseries")
async def get_timeseries(
    metric: str = Query("pps", regex="^(pps|mbps)$"),
    seconds: int = Query(60, ge=10, le=120),
):
    return {"metric": metric, "data": stats_service.timeseries(metric, seconds)}


@router.get("/protocols")
async def get_protocols():
    snap = stats_service.snapshot()
    total = snap["total_packets"] or 1
    return {
        "protocols": [
            {
                "protocol": proto,
                "count": count,
                "pct": round(count / total * 100, 1),
            }
            for proto, count in snap["proto_counts"].items()
        ]
    }


@router.get("/top-talkers")
async def get_top_talkers():
    snap = stats_service.snapshot()
    return {"top_ips": snap["top_ips"], "top_ports": snap["top_ports"]}


@router.get("/dns")
async def get_dns():
    snap = stats_service.snapshot()
    return {"top_dns_queries": snap["top_dns"]}


@router.get("/http")
async def get_http():
    snap = stats_service.snapshot()
    return {"top_http_hosts": snap["top_http_hosts"]}
