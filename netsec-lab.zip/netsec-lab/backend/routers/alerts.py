"""
/alerts/* endpoints
- GET /alerts/          paginated Suricata alerts from DB
- GET /alerts/summary   severity/category breakdown
- GET /alerts/{id}      single alert detail
"""
from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select, func, desc
from sqlalchemy.ext.asyncio import AsyncSession

from backend.database import get_db
from backend.models.alert import Alert

router = APIRouter(prefix="/alerts", tags=["alerts"])


@router.get("/")
async def list_alerts(
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=200),
    event_type: str | None = None,
    severity: int | None = None,
    src_ip: str | None = None,
    db: AsyncSession = Depends(get_db),
):
    stmt = select(Alert).order_by(desc(Alert.timestamp))
    if event_type:
        stmt = stmt.where(Alert.event_type == event_type)
    if severity is not None:
        stmt = stmt.where(Alert.severity == severity)
    if src_ip:
        stmt = stmt.where(Alert.src_ip == src_ip)

    count_stmt = select(func.count()).select_from(stmt.subquery())
    total = (await db.execute(count_stmt)).scalar_one()

    stmt = stmt.offset((page - 1) * page_size).limit(page_size)
    rows = (await db.execute(stmt)).scalars().all()

    return {
        "total":     total,
        "page":      page,
        "page_size": page_size,
        "items":     [r.to_dict() for r in rows],
    }


@router.get("/summary")
async def alerts_summary(db: AsyncSession = Depends(get_db)):
    # severity breakdown
    sev_rows = (await db.execute(
        select(Alert.severity, func.count().label("cnt"))
        .group_by(Alert.severity)
        .order_by(Alert.severity)
    )).all()

    # top signatures
    sig_rows = (await db.execute(
        select(Alert.signature, func.count().label("cnt"))
        .where(Alert.event_type == "alert")
        .group_by(Alert.signature)
        .order_by(desc("cnt"))
        .limit(10)
    )).all()

    # top categories
    cat_rows = (await db.execute(
        select(Alert.category, func.count().label("cnt"))
        .where(Alert.event_type == "alert")
        .group_by(Alert.category)
        .order_by(desc("cnt"))
        .limit(10)
    )).all()

    # event type counts
    etype_rows = (await db.execute(
        select(Alert.event_type, func.count().label("cnt"))
        .group_by(Alert.event_type)
        .order_by(desc("cnt"))
    )).all()

    return {
        "severity_breakdown":  [{"severity": r.severity, "count": r.cnt} for r in sev_rows],
        "top_signatures":      [{"signature": r.signature, "count": r.cnt} for r in sig_rows],
        "top_categories":      [{"category": r.category, "count": r.cnt} for r in cat_rows],
        "event_type_counts":   [{"event_type": r.event_type, "count": r.cnt} for r in etype_rows],
    }


@router.get("/{alert_id}")
async def get_alert(alert_id: int, db: AsyncSession = Depends(get_db)):
    row = await db.get(Alert, alert_id)
    if not row:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="Alert not found")
    return row.to_dict()
