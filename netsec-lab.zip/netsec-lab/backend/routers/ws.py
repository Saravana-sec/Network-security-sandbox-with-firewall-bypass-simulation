"""
WebSocket router — /ws/live
Drains the shared asyncio queue, broadcasts to all connected clients,
and persists packets/alerts to SQLite via db_service.
"""
from __future__ import annotations

import asyncio
import json

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from backend.services.ws_manager import manager
from backend.services.stats_service import stats_service
from backend.services import db_service

router = APIRouter()

# Shared queue — capture_service and suricata_service both push here
live_queue: asyncio.Queue = asyncio.Queue(maxsize=2000)


@router.websocket("/ws/live")
async def websocket_live(ws: WebSocket):
    await manager.connect(ws)
    try:
        # Send an initial stats snapshot so the UI has data immediately
        await ws.send_text(json.dumps({
            "type": "stats",
            "data": stats_service.snapshot(),
        }))
        # Keep the connection alive; client may send pings or filter commands
        while True:
            try:
                await asyncio.wait_for(ws.receive_text(), timeout=30)
            except asyncio.TimeoutError:
                await ws.send_text(json.dumps({"type": "ping"}))
    except WebSocketDisconnect:
        pass
    finally:
        await manager.disconnect(ws)


async def broadcast_loop():
    """
    Background task — drains live_queue, broadcasts to WS clients,
    feeds stats aggregator, and persists to DB.
    Batches up to 25 packets per tick.
    """
    packet_batch: list[dict] = []
    db_flush_counter = 0

    while True:
        try:
            item = await asyncio.wait_for(live_queue.get(), timeout=0.1)
        except asyncio.TimeoutError:
            # Flush packet batch even if not full
            if packet_batch:
                await manager.broadcast({"type": "packets", "data": packet_batch})
                for p in packet_batch:
                    await db_service.persist_packet(p)
                packet_batch = []

            # Periodic stats push and DB flush
            db_flush_counter += 1
            if db_flush_counter >= 30:           # every ~3 seconds
                db_flush_counter = 0
                await db_service.flush_all()
                if manager.count > 0:
                    await manager.broadcast({
                        "type": "stats",
                        "data": stats_service.snapshot(),
                    })
            continue

        if item.get("type") == "suricata":
            # Flush packets first, then send alert immediately
            if packet_batch:
                await manager.broadcast({"type": "packets", "data": packet_batch})
                for p in packet_batch:
                    await db_service.persist_packet(p)
                packet_batch = []

            alert_data = item["data"]
            stats_service.ingest_alert(alert_data)
            await db_service.persist_alert(alert_data)
            await manager.broadcast({"type": "alert", "data": alert_data})

        else:
            # Raw packet dict from capture_service
            stats_service.ingest_packet(item)
            packet_batch.append(item)
            if len(packet_batch) >= 25:
                await manager.broadcast({"type": "packets", "data": packet_batch})
                for p in packet_batch:
                    await db_service.persist_packet(p)
                packet_batch = []

        live_queue.task_done()
