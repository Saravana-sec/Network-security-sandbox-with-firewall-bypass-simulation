"""
/capture/* endpoints
- GET  /capture/interfaces        list available NICs
- POST /capture/start             start live capture
- POST /capture/stop              stop live capture
- GET  /capture/status            current capture status + stats
"""
from __future__ import annotations

import asyncio

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from backend.services.capture_service import capture_service
from backend.services.suricata_service import suricata_service
from backend.routers.ws import live_queue

router = APIRouter(prefix="/capture", tags=["capture"])


class StartRequest(BaseModel):
    interface: str = "eth0"
    bpf_filter: str = ""


@router.get("/interfaces")
async def list_interfaces():
    try:
        ifaces = capture_service.available_interfaces()
        return {"interfaces": ifaces}
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc))


@router.post("/start")
async def start_capture(req: StartRequest):
    if capture_service.is_running:
        raise HTTPException(status_code=409, detail="Capture already running")
    loop = asyncio.get_event_loop()
    capture_service.start(
        interface=req.interface,
        bpf_filter=req.bpf_filter,
        queue=live_queue,
        loop=loop,
    )
    suricata_service.start(queue=live_queue)
    return {"status": "started", "interface": req.interface, "filter": req.bpf_filter}


@router.post("/stop")
async def stop_capture():
    if not capture_service.is_running:
        raise HTTPException(status_code=409, detail="Capture not running")
    capture_service.stop()
    suricata_service.stop()
    return {"status": "stopped"}


@router.get("/status")
async def capture_status():
    return {
        "capture":  capture_service.stats,
        "suricata": suricata_service.stats,
    }
