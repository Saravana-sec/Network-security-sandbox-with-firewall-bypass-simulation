"""
In-memory stats aggregation. Maintains rolling counters and
time-series buckets used by the dashboard widgets.
"""
from __future__ import annotations

import time
from collections import defaultdict, deque
from threading import Lock
from typing import Any


class StatsService:
    HISTORY_SECONDS = 120  # keep 2 min of per-second buckets

    def __init__(self):
        self._lock = Lock()
        # per-second ring buffers
        self._pps_history: deque[tuple[float, int]] = deque()   # (ts, count)
        self._bps_history: deque[tuple[float, int]] = deque()   # (ts, bytes)
        # rolling totals
        self._total_packets = 0
        self._total_bytes = 0
        self._total_alerts = 0
        # counters
        self._proto_counts: dict[str, int] = defaultdict(int)
        self._port_counts: dict[int, int] = defaultdict(int)
        self._ip_counts: dict[str, int] = defaultdict(int)
        self._alert_sigs: dict[str, int] = defaultdict(int)
        self._dns_queries: dict[str, int] = defaultdict(int)
        self._http_hosts: dict[str, int] = defaultdict(int)
        # current-second accumulators
        self._cur_sec: int = int(time.time())
        self._cur_pkts: int = 0
        self._cur_bytes: int = 0

    # ── ingestion ──────────────────────────────────────────────────

    def ingest_packet(self, pkt: dict) -> None:
        with self._lock:
            now = int(time.time())
            if now != self._cur_sec:
                self._flush_second(now)

            self._cur_pkts += 1
            self._cur_bytes += pkt.get("length", 0)
            self._total_packets += 1
            self._total_bytes += pkt.get("length", 0)

            proto = pkt.get("protocol", "OTHER")
            self._proto_counts[proto] += 1

            dport = pkt.get("dst_port")
            if dport:
                self._port_counts[dport] += 1

            src = pkt.get("src_ip")
            if src:
                self._ip_counts[src] += 1

            extra = pkt.get("extra", {})
            if q := extra.get("dns_query"):
                self._dns_queries[q] += 1
            if h := extra.get("http_host"):
                self._http_hosts[h] += 1

    def ingest_alert(self, alert: dict) -> None:
        with self._lock:
            self._total_alerts += 1
            sig = alert.get("signature") or "unknown"
            self._alert_sigs[sig] += 1

    # ── queries ────────────────────────────────────────────────────

    def snapshot(self) -> dict[str, Any]:
        with self._lock:
            self._flush_second(int(time.time()))
            pps = self._rate_from_history(self._pps_history, window=10)
            mbps = self._rate_from_history(self._bps_history, window=10) * 8 / 1_000_000

            return {
                "total_packets":  self._total_packets,
                "total_bytes":    self._total_bytes,
                "total_alerts":   self._total_alerts,
                "pps":            round(pps, 1),
                "mbps":           round(mbps, 3),
                "proto_counts":   dict(sorted(self._proto_counts.items(),
                                              key=lambda x: x[1], reverse=True)),
                "top_ports":      self._top_n(self._port_counts, 10),
                "top_ips":        self._top_n(self._ip_counts, 10),
                "top_alert_sigs": self._top_n(self._alert_sigs, 10),
                "top_dns":        self._top_n(self._dns_queries, 10),
                "top_http_hosts": self._top_n(self._http_hosts, 10),
            }

    def timeseries(self, metric: str = "pps", seconds: int = 60) -> list[dict]:
        with self._lock:
            if metric == "mbps":
                src = self._bps_history
                scale = 8 / 1_000_000
            else:
                src = self._pps_history
                scale = 1.0
            cutoff = time.time() - seconds
            return [
                {"ts": ts, "value": round(count * scale, 3)}
                for ts, count in src
                if ts >= cutoff
            ]

    def reset(self) -> None:
        with self._lock:
            self.__init__()  # type: ignore[misc]

    # ── helpers ────────────────────────────────────────────────────

    def _flush_second(self, now: int) -> None:
        if self._cur_pkts or self._cur_bytes:
            self._pps_history.append((self._cur_sec, self._cur_pkts))
            self._bps_history.append((self._cur_sec, self._cur_bytes))
        self._cur_sec = now
        self._cur_pkts = 0
        self._cur_bytes = 0
        cutoff = time.time() - self.HISTORY_SECONDS
        while self._pps_history and self._pps_history[0][0] < cutoff:
            self._pps_history.popleft()
        while self._bps_history and self._bps_history[0][0] < cutoff:
            self._bps_history.popleft()

    @staticmethod
    def _top_n(counter: dict, n: int) -> list[dict]:
        return [
            {"key": str(k), "count": v}
            for k, v in sorted(counter.items(), key=lambda x: x[1], reverse=True)[:n]
        ]

    @staticmethod
    def _rate_from_history(history: deque, window: int) -> float:
        if not history:
            return 0.0
        cutoff = time.time() - window
        total = sum(count for ts, count in history if ts >= cutoff)
        return total / window


stats_service = StatsService()
