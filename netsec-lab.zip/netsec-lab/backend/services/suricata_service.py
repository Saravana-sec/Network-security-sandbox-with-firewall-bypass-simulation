"""
Suricata eve.json live-tail service.
Reads the JSON log line-by-line, parses all event types
(alert, dns, http, tls, flow, stats) and pushes them to the broadcast queue.
"""
from __future__ import annotations

import asyncio
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from backend.config import settings


class SuricataService:
    def __init__(self):
        self._running = False
        self._task: Optional[asyncio.Task] = None
        self._queue: Optional[asyncio.Queue] = None
        self._eve_path = Path(settings.SURICATA_EVE_LOG)
        self._line_count = 0
        self._alert_count = 0
        self._last_pos = 0

    # ── public ─────────────────────────────────────────────────────

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def stats(self) -> dict:
        return {
            "running":      self._running,
            "eve_path":     str(self._eve_path),
            "eve_exists":   self._eve_path.exists(),
            "line_count":   self._line_count,
            "alert_count":  self._alert_count,
        }

    def start(self, queue: asyncio.Queue) -> None:
        if self._running:
            return
        if not settings.SURICATA_ENABLED:
            return
        self._queue = queue
        self._running = True
        self._task = asyncio.create_task(self._tail_loop())

    def stop(self) -> None:
        self._running = False
        if self._task:
            self._task.cancel()

    # ── internal ───────────────────────────────────────────────────

    async def _tail_loop(self) -> None:
        """Continuously tail eve.json like `tail -F`."""
        while self._running:
            if not self._eve_path.exists():
                await asyncio.sleep(2)
                continue
            try:
                with open(self._eve_path, "r", errors="replace") as fh:
                    fh.seek(0, 2)                   # jump to EOF on first open
                    self._last_pos = fh.tell()
                    while self._running:
                        line = fh.readline()
                        if not line:
                            # check for file rotation
                            try:
                                if os.stat(self._eve_path).st_size < self._last_pos:
                                    break           # file rotated — reopen
                            except OSError:
                                break
                            await asyncio.sleep(0.1)
                            continue
                        self._last_pos = fh.tell()
                        await self._handle_line(line.strip())
            except Exception as exc:
                print(f"[suricata] tail error: {exc}")
                await asyncio.sleep(2)

    async def _handle_line(self, line: str) -> None:
        if not line:
            return
        try:
            evt = json.loads(line)
        except json.JSONDecodeError:
            return

        self._line_count += 1
        parsed = self._parse_event(evt)
        if parsed and self._queue:
            if parsed.get("event_type") == "alert":
                self._alert_count += 1
            await self._queue.put({"type": "suricata", "data": parsed})

    @staticmethod
    def _parse_event(evt: dict) -> Optional[dict]:
        etype = evt.get("event_type", "unknown")

        base = {
            "event_type": etype,
            "timestamp":  evt.get("timestamp", datetime.now(timezone.utc).isoformat()),
            "src_ip":     evt.get("src_ip"),
            "dst_ip":     evt.get("dest_ip"),
            "src_port":   evt.get("src_port"),
            "dst_port":   evt.get("dest_port"),
            "protocol":   evt.get("proto"),
            "flow_id":    str(evt.get("flow_id", "")),
        }

        if etype == "alert":
            alert_info = evt.get("alert", {})
            base.update({
                "severity":  alert_info.get("severity"),
                "signature": alert_info.get("signature"),
                "sig_id":    alert_info.get("signature_id"),
                "category":  alert_info.get("category"),
                "action":    alert_info.get("action"),
                "rev":       alert_info.get("rev"),
            })

        elif etype == "dns":
            dns = evt.get("dns", {})
            base.update({
                "dns_type":    dns.get("type"),
                "dns_query":   dns.get("rrname"),
                "dns_qtype":   dns.get("rrtype"),
                "dns_answers": dns.get("answers", []),
                "dns_rcode":   dns.get("rcode"),
            })

        elif etype == "http":
            http = evt.get("http", {})
            base.update({
                "http_host":      http.get("hostname"),
                "http_uri":       http.get("url"),
                "http_method":    http.get("http_method"),
                "http_status":    http.get("status"),
                "http_ua":        http.get("http_user_agent"),
                "http_length":    http.get("length"),
                "http_content_type": http.get("http_content_type"),
            })

        elif etype == "tls":
            tls = evt.get("tls", {})
            base.update({
                "tls_sni":     tls.get("sni"),
                "tls_version": tls.get("version"),
                "tls_subject": tls.get("subject"),
                "tls_issuer":  tls.get("issuerdn"),
                "tls_ja3":     tls.get("ja3", {}).get("hash"),
                "tls_ja3s":    tls.get("ja3s", {}).get("hash"),
            })

        elif etype == "flow":
            flow = evt.get("flow", {})
            base.update({
                "flow_state":      flow.get("state"),
                "flow_reason":     flow.get("reason"),
                "pkts_toserver":   flow.get("pkts_toserver"),
                "pkts_toclient":   flow.get("pkts_toclient"),
                "bytes_toserver":  flow.get("bytes_toserver"),
                "bytes_toclient":  flow.get("bytes_toclient"),
                "app_proto":       evt.get("app_proto"),
            })

        elif etype == "stats":
            stats = evt.get("stats", {})
            base.update({
                "uptime":       stats.get("uptime"),
                "capture_kpps": stats.get("capture", {}).get("kernel_packets"),
                "decoder_pkts": stats.get("decoder", {}).get("pkts"),
                "alert_count":  stats.get("detect", {}).get("alert"),
            })

        return base


suricata_service = SuricataService()
