"""
GeoIP lookup service using MaxMind GeoLite2 (free).
Falls back to a stub when the mmdb is not downloaded yet.
"""
from __future__ import annotations
import ipaddress
from typing import Optional
from backend.config import settings


class GeoIPService:
    def __init__(self):
        self._reader = None
        if settings.GEOIP_ENABLED:
            try:
                import geoip2.database
                self._reader = geoip2.database.Reader(settings.GEOIP_DB_PATH)
            except Exception as exc:
                print(f"[geoip] could not load mmdb: {exc} — geo disabled")

    def lookup(self, ip: str) -> Optional[str]:
        if not self._reader or not ip:
            return None
        try:
            if ipaddress.ip_address(ip).is_private:
                return "Private"
            r = self._reader.city(ip)
            parts = [r.country.iso_code]
            if r.city.name:
                parts.append(r.city.name)
            return ", ".join(filter(None, parts))
        except Exception:
            return None

    def lookup_full(self, ip: str) -> Optional[dict]:
        if not self._reader or not ip:
            return None
        try:
            if ipaddress.ip_address(ip).is_private:
                return {"country": "Private", "city": None, "lat": None, "lon": None}
            r = self._reader.city(ip)
            return {
                "country":     r.country.name,
                "country_iso": r.country.iso_code,
                "city":        r.city.name,
                "lat":         r.location.latitude,
                "lon":         r.location.longitude,
            }
        except Exception:
            return None
