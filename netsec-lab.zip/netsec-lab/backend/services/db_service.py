"""
Persistence service — drains the live queue and writes
packets + alerts to SQLite in background batches.
Called from the broadcast_loop so no extra task needed.
"""
from __future__ import annotations

from datetime import datetime, timezone
from sqlalchemy.ext.asyncio import AsyncSession

from backend.database import AsyncSessionLocal
from backend.models.packet import Packet
from backend.models.alert import Alert
from backend.config import settings

_packet_batch: list[dict] = []
_alert_batch:  list[dict] = []
BATCH_SIZE = 50


async def persist_packet(data: dict) -> None:
    global _packet_batch
    _packet_batch.append(data)
    if len(_packet_batch) >= BATCH_SIZE:
        await _flush_packets()


async def persist_alert(data: dict) -> None:
    global _alert_batch
    _alert_batch.append(data)
    if len(_alert_batch) >= 10:
        await _flush_alerts()


async def flush_all() -> None:
    await _flush_packets()
    await _flush_alerts()


async def _flush_packets() -> None:
    global _packet_batch
    if not _packet_batch:
        return
    batch = _packet_batch[:settings.MAX_PACKET_BUFFER]
    _packet_batch = []
    try:
        async with AsyncSessionLocal() as session:
            async with session.begin():
                for d in batch:
                    ts = None
                    if d.get("timestamp"):
                        try:
                            ts = datetime.fromisoformat(d["timestamp"].replace("Z", "+00:00"))
                        except ValueError:
                            ts = datetime.now(timezone.utc)
                    session.add(Packet(
                        timestamp   = ts,
                        src_ip      = d.get("src_ip"),
                        dst_ip      = d.get("dst_ip"),
                        src_port    = d.get("src_port"),
                        dst_port    = d.get("dst_port"),
                        protocol    = d.get("protocol"),
                        length      = d.get("length", 0),
                        ttl         = d.get("ttl"),
                        flags       = d.get("flags"),
                        payload_len = d.get("payload_len", 0),
                        summary     = d.get("summary", "")[:200],
                        interface   = d.get("interface"),
                        geo_src     = d.get("geo_src"),
                        geo_dst     = d.get("geo_dst"),
                    ))
                # Ring-buffer pruning: delete oldest beyond MAX_PACKET_BUFFER
                from sqlalchemy import text
                await session.execute(text(
                    f"DELETE FROM packets WHERE id NOT IN "
                    f"(SELECT id FROM packets ORDER BY id DESC LIMIT {settings.MAX_PACKET_BUFFER})"
                ))
    except Exception as exc:
        print(f"[db] packet flush error: {exc}")


async def _flush_alerts() -> None:
    global _alert_batch
    if not _alert_batch:
        return
    batch = _alert_batch[:]
    _alert_batch = []
    try:
        async with AsyncSessionLocal() as session:
            async with session.begin():
                for d in batch:
                    ts = None
                    if d.get("timestamp"):
                        try:
                            ts = datetime.fromisoformat(d["timestamp"].replace("Z", "+00:00"))
                        except ValueError:
                            ts = datetime.now(timezone.utc)
                    session.add(Alert(
                        timestamp   = ts,
                        event_type  = d.get("event_type"),
                        severity    = d.get("severity"),
                        signature   = d.get("signature"),
                        sig_id      = d.get("sig_id"),
                        category    = d.get("category"),
                        src_ip      = d.get("src_ip"),
                        dst_ip      = d.get("dst_ip"),
                        src_port    = d.get("src_port"),
                        dst_port    = d.get("dst_port"),
                        protocol    = d.get("protocol"),
                        action      = d.get("action"),
                        flow_id     = d.get("flow_id"),
                        http_host   = d.get("http_host"),
                        http_uri    = d.get("http_uri"),
                        dns_query   = d.get("dns_query"),
                        tls_sni     = d.get("tls_sni"),
                        raw         = d,
                    ))
    except Exception as exc:
        print(f"[db] alert flush error: {exc}")
