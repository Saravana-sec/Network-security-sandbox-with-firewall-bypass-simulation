"""
Live packet capture service using Scapy.
Runs in a background daemon thread; pushes parsed dicts into an
asyncio.Queue that the WebSocket router drains and broadcasts.
"""
from __future__ import annotations

import asyncio
import threading
import time
from datetime import datetime, timezone
from typing import Optional

from scapy.all import sniff, get_if_list
from scapy.layers.inet import IP, TCP, UDP, ICMP
from scapy.layers.inet6 import IPv6
from scapy.layers.dns import DNS, DNSQR, DNSRR
from scapy.layers.l2 import ARP
try:
    from scapy.layers.http import HTTPRequest, HTTPResponse
    _HTTP = True
except ImportError:
    _HTTP = False

from backend.config import settings
from backend.services.geoip_service import GeoIPService


PORT_MAP: dict[int, str] = {
    20: "FTP-data", 21: "FTP", 22: "SSH", 23: "Telnet",
    25: "SMTP", 53: "DNS", 67: "DHCP", 68: "DHCP",
    80: "HTTP", 110: "POP3", 123: "NTP", 143: "IMAP",
    161: "SNMP", 389: "LDAP", 443: "HTTPS", 445: "SMB",
    465: "SMTPS", 587: "SMTP", 636: "LDAPS", 993: "IMAPS",
    995: "POP3S", 1433: "MSSQL", 1521: "Oracle",
    3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL",
    5900: "VNC", 6379: "Redis", 8080: "HTTP-alt",
    8443: "HTTPS-alt", 27017: "MongoDB", 9200: "Elasticsearch",
}


class CaptureService:
    def __init__(self):
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._loop: Optional[asyncio.AbstractEventLoop] = None
        self._queue: Optional[asyncio.Queue] = None
        self._interface: str = settings.DEFAULT_INTERFACE
        self._bpf_filter: str = settings.CAPTURE_FILTER
        self._packet_count: int = 0
        self._byte_count: int = 0
        self._start_time: Optional[float] = None
        self._proto_counts: dict[str, int] = {}
        self._lock = threading.Lock()
        self._geoip = GeoIPService()

    # ── public ─────────────────────────────────────────────────────

    @staticmethod
    def available_interfaces() -> list[str]:
        return get_if_list()

    @property
    def is_running(self) -> bool:
        return self._running

    @property
    def stats(self) -> dict:
        elapsed = time.time() - self._start_time if self._start_time else 0
        with self._lock:
            proto_snap = dict(self._proto_counts)
        return {
            "running":       self._running,
            "interface":     self._interface,
            "filter":        self._bpf_filter,
            "packet_count":  self._packet_count,
            "byte_count":    self._byte_count,
            "elapsed_sec":   round(elapsed, 1),
            "pps":           round(self._packet_count / elapsed, 1) if elapsed > 1 else 0,
            "mbps":          round((self._byte_count * 8) / (elapsed * 1_000_000), 3) if elapsed > 1 else 0,
            "proto_counts":  proto_snap,
        }

    def start(
        self,
        interface: str,
        bpf_filter: str,
        queue: asyncio.Queue,
        loop: asyncio.AbstractEventLoop,
    ) -> None:
        if self._running:
            return
        self._interface = interface
        self._bpf_filter = bpf_filter
        self._queue = queue
        self._loop = loop
        self._packet_count = 0
        self._byte_count = 0
        self._proto_counts = {}
        self._start_time = time.time()
        self._running = True
        self._thread = threading.Thread(target=self._capture_thread, daemon=True, name="scapy-capture")
        self._thread.start()

    def stop(self) -> None:
        self._running = False

    # ── internal ───────────────────────────────────────────────────

    def _capture_thread(self) -> None:
        try:
            sniff(
                iface=self._interface,
                filter=self._bpf_filter or None,
                prn=self._handle_packet,
                store=False,
                stop_filter=lambda _: not self._running,
            )
        except Exception as exc:
            print(f"[capture] sniff error: {exc}")
        finally:
            self._running = False

    def _handle_packet(self, pkt) -> None:
        try:
            parsed = self._parse(pkt)
            if not parsed:
                return
            with self._lock:
                self._packet_count += 1
                self._byte_count += parsed["length"]
                p = parsed["protocol"]
                self._proto_counts[p] = self._proto_counts.get(p, 0) + 1
            if self._loop and self._queue:
                asyncio.run_coroutine_threadsafe(self._queue.put(parsed), self._loop)
        except Exception as exc:
            print(f"[capture] handle error: {exc}")

    def _parse(self, pkt) -> Optional[dict]:
        length = len(pkt)
        now = datetime.now(timezone.utc).isoformat()

        # ── ARP ────────────────────────────────────────────────────
        if pkt.haslayer(ARP):
            arp = pkt[ARP]
            return {
                "timestamp":   now,
                "src_ip":      arp.psrc,
                "dst_ip":      arp.pdst,
                "src_mac":     arp.hwsrc,
                "dst_mac":     arp.hwdst,
                "src_port":    None,
                "dst_port":    None,
                "protocol":    "ARP",
                "length":      length,
                "ttl":         None,
                "flags":       "request" if arp.op == 1 else "reply",
                "payload_len": 0,
                "summary":     pkt.summary(),
                "geo_src":     None,
                "geo_dst":     None,
                "extra":       {},
            }

        # ── IP/IPv6 ────────────────────────────────────────────────
        src_ip = dst_ip = None
        ttl = None
        if pkt.haslayer(IP):
            src_ip, dst_ip, ttl = pkt[IP].src, pkt[IP].dst, pkt[IP].ttl
        elif pkt.haslayer(IPv6):
            src_ip, dst_ip, ttl = pkt[IPv6].src, pkt[IPv6].dst, pkt[IPv6].hlim
        else:
            return None

        src_port = dst_port = flags = None
        extra: dict = {}
        transport = "OTHER"

        if pkt.haslayer(TCP):
            tcp = pkt[TCP]
            src_port, dst_port = tcp.sport, tcp.dport
            flags = self._tcp_flags(int(tcp.flags))
            transport = "TCP"
        elif pkt.haslayer(UDP):
            udp = pkt[UDP]
            src_port, dst_port = udp.sport, udp.dport
            transport = "UDP"
        elif pkt.haslayer(ICMP):
            transport = "ICMP"
            flags = f"type={pkt[ICMP].type}/code={pkt[ICMP].code}"

        protocol = self._infer_proto(src_port, dst_port, transport, pkt)

        # ── protocol-specific extras ───────────────────────────────
        if pkt.haslayer(DNS):
            try:
                if pkt[DNS].qd:
                    extra["dns_query"] = pkt[DNS].qd.qname.decode(errors="replace").rstrip(".")
                    extra["dns_qtype"] = pkt[DNS].qd.qtype
                if pkt[DNS].an:
                    rdata = pkt[DNS].an.rdata
                    extra["dns_answer"] = str(rdata) if rdata else None
            except Exception:
                pass

        if _HTTP:
            if pkt.haslayer(HTTPRequest):
                try:
                    hr = pkt[HTTPRequest]
                    extra["http_method"] = hr.Method.decode(errors="replace")
                    extra["http_host"]   = hr.Host.decode(errors="replace") if hr.Host else None
                    extra["http_path"]   = hr.Path.decode(errors="replace")  if hr.Path else None
                except Exception:
                    pass
            elif pkt.haslayer(HTTPResponse):
                try:
                    extra["http_status"] = pkt[HTTPResponse].Status_Code.decode(errors="replace")
                except Exception:
                    pass

        payload_len = max(0, length - (len(pkt) - len(pkt.payload)))

        return {
            "timestamp":   now,
            "src_ip":      src_ip,
            "dst_ip":      dst_ip,
            "src_port":    src_port,
            "dst_port":    dst_port,
            "protocol":    protocol,
            "length":      length,
            "ttl":         ttl,
            "flags":       flags,
            "payload_len": payload_len,
            "summary":     pkt.summary()[:200],
            "geo_src":     self._geoip.lookup(src_ip),
            "geo_dst":     self._geoip.lookup(dst_ip),
            "extra":       extra,
        }

    @staticmethod
    def _tcp_flags(flags_int: int) -> str:
        names = {0x01: "FIN", 0x02: "SYN", 0x04: "RST",
                 0x08: "PSH", 0x10: "ACK", 0x20: "URG"}
        result = "/".join(name for bit, name in names.items() if flags_int & bit)
        return result or str(flags_int)

    @staticmethod
    def _infer_proto(sport, dport, transport: str, pkt) -> str:
        if pkt.haslayer(DNS):
            return "DNS"
        if _HTTP and (pkt.haslayer(HTTPRequest) or pkt.haslayer(HTTPResponse)):
            return "HTTP"
        for port in (dport, sport):
            if port and port in PORT_MAP:
                return PORT_MAP[port]
        return transport


capture_service = CaptureService()
