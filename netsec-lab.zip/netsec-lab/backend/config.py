from pydantic_settings import BaseSettings
from pathlib import Path


class Settings(BaseSettings):
    APP_NAME: str = "NetSec Lab"
    APP_VERSION: str = "1.0.0"
    DEBUG: bool = True

    DEFAULT_INTERFACE: str = "eth0"
    CAPTURE_FILTER: str = ""
    MAX_PACKET_BUFFER: int = 5000

    SURICATA_EVE_LOG: str = "/var/log/suricata/eve.json"
    SURICATA_ENABLED: bool = True

    GEOIP_DB_PATH: str = str(Path(__file__).parent.parent / "data" / "GeoLite2-City.mmdb")
    GEOIP_ENABLED: bool = False

    DATABASE_URL: str = "sqlite+aiosqlite:///./netsec.db"

    ALLOWED_ORIGINS: list[str] = [
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ]

    class Config:
        env_file = ".env"


settings = Settings()
