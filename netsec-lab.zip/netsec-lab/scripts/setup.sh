#!/usr/bin/env bash
# =============================================================================
# NetSec Lab — WSL2 setup script
# Run once: bash scripts/setup.sh
# =============================================================================
set -euo pipefail

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; RED='\033[0;31m'; NC='\033[0m'
info()  { echo -e "${CYAN}[setup]${NC} $*"; }
ok()    { echo -e "${GREEN}[  ok ]${NC} $*"; }
warn()  { echo -e "${YELLOW}[ warn]${NC} $*"; }
err()   { echo -e "${RED}[error]${NC} $*"; exit 1; }

# ── Check WSL2 ───────────────────────────────────────────────────────────────
if ! grep -qi microsoft /proc/version 2>/dev/null; then
  warn "Not detected as WSL2 — continuing anyway, some steps may differ"
fi

# ── System packages ──────────────────────────────────────────────────────────
info "Updating apt and installing system packages…"
sudo apt-get update -qq
sudo apt-get install -y -qq \
  python3 python3-pip python3-venv \
  libpcap-dev \
  tcpdump \
  curl wget git \
  build-essential \
  suricata \
  suricata-update \
  nodejs npm

ok "System packages installed"

# ── Python venv ──────────────────────────────────────────────────────────────
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
cd "$PROJECT_DIR"

info "Creating Python virtual environment…"
python3 -m venv .venv
source .venv/bin/activate
pip install -q --upgrade pip
pip install -q -r requirements.txt
ok "Python dependencies installed"

# ── Suricata setup ───────────────────────────────────────────────────────────
info "Configuring Suricata…"

# Create log dir
sudo mkdir -p /var/log/suricata
sudo chown -R "$USER":"$USER" /var/log/suricata

# Update rules
sudo suricata-update --no-merge 2>/dev/null || warn "suricata-update failed — you can run it manually later"

# Detect default interface
DEFAULT_IFACE=$(ip route show default 2>/dev/null | awk '/default/ {print $5; exit}')
DEFAULT_IFACE="${DEFAULT_IFACE:-eth0}"
info "Detected default interface: $DEFAULT_IFACE"

# Patch our suricata.yaml with the real interface
sed -i "s/interface: eth0/interface: $DEFAULT_IFACE/g" "$PROJECT_DIR/suricata-config/suricata.yaml"

# Copy config
sudo cp "$PROJECT_DIR/suricata-config/suricata.yaml" /etc/suricata/suricata.yaml
ok "Suricata configured (interface: $DEFAULT_IFACE)"

# ── .env defaults ────────────────────────────────────────────────────────────
if [[ ! -f "$PROJECT_DIR/.env" ]]; then
  cp "$PROJECT_DIR/.env.example" "$PROJECT_DIR/.env" 2>/dev/null || true
fi

# Patch interface in .env
sed -i "s/DEFAULT_INTERFACE=eth0/DEFAULT_INTERFACE=$DEFAULT_IFACE/" "$PROJECT_DIR/.env" 2>/dev/null || true

# ── Create data directory ────────────────────────────────────────────────────
mkdir -p "$PROJECT_DIR/data"
info "data/ directory ready (place GeoLite2-City.mmdb here for geo features)"

# ── Frontend dependencies ────────────────────────────────────────────────────
info "Installing frontend dependencies…"
cd "$PROJECT_DIR/frontend"
npm install --silent
cd "$PROJECT_DIR"
ok "Frontend dependencies installed"

# ── Verify Suricata ──────────────────────────────────────────────────────────
if command -v suricata &>/dev/null; then
  SURICATA_VER=$(suricata --build-info 2>/dev/null | grep "^Suricata version" | awk '{print $3}')
  ok "Suricata ${SURICATA_VER} ready"
else
  warn "Suricata binary not found — install manually: sudo apt install suricata"
fi

# ── Print summary ────────────────────────────────────────────────────────────
echo ""
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${GREEN}  NetSec Lab setup complete!${NC}"
echo -e "${GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo ""
echo "  Interface detected : $DEFAULT_IFACE"
echo ""
echo "  Next steps:"
echo ""
echo "  1. Start Suricata (in a separate terminal):"
echo -e "     ${CYAN}sudo suricata -c /etc/suricata/suricata.yaml -i $DEFAULT_IFACE${NC}"
echo ""
echo "  2. Start the backend (needs root for raw socket capture):"
echo -e "     ${CYAN}source .venv/bin/activate${NC}"
echo -e "     ${CYAN}sudo .venv/bin/uvicorn backend.main:app --host 0.0.0.0 --port 8000 --reload${NC}"
echo ""
echo "  3. Start the frontend (in a separate terminal):"
echo -e "     ${CYAN}cd frontend && npm run dev${NC}"
echo ""
echo "  4. Open in your Windows browser:"
echo -e "     ${CYAN}http://localhost:5173${NC}"
echo ""
echo "  Optional — enable GeoIP:"
echo "    Download GeoLite2-City.mmdb from https://dev.maxmind.com"
echo "    Place it at: data/GeoLite2-City.mmdb"
echo "    Set GEOIP_ENABLED=true in .env"
echo ""
