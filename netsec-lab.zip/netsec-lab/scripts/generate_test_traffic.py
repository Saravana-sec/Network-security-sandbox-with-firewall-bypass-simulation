#!/usr/bin/env python3
"""
NetSec Lab — test traffic generator
Pushes realistic-looking packet and alert data into the live WebSocket
so you can develop / test the UI without root or a live NIC.

Usage:
    python scripts/generate_test_traffic.py
"""
import asyncio
import json
import random
import time
from datetime import datetime, timezone
import websockets

WS_URL = "ws://localhost:8000/ws/live"

PROTOCOLS = ["TCP", "UDP", "DNS", "HTTP", "HTTPS", "ICMP", "SSH", "TLS", "ARP", "SMTP"]
PRIVATE_IPS = [
    "192.168.1.1", "192.168.1.10", "192.168.1.42", "192.168.1.100",
    "10.0.0.1", "10.0.0.5", "10.0.1.55", "172.16.0.10",
]
PUBLIC_IPS = [
    "8.8.8.8", "1.1.1.1", "142.250.80.46", "13.107.42.16",
    "151.101.65.140", "104.244.42.65", "185.60.216.35", "31.13.66.35",
    "52.84.18.100", "54.230.100.200", "23.185.0.1", "199.232.41.194",
]
TCP_FLAGS = ["SYN", "ACK", "SYN/ACK", "FIN/ACK", "RST", "PSH/ACK"]
PORT_MAP = {
    "TCP": [80, 443, 22, 3306, 8080, 445, 3389, 5432],
    "UDP": [53, 123, 161, 67, 68, 500],
    "DNS": [53], "HTTP": [80, 8080], "HTTPS": [443, 8443],
    "SSH": [22], "SMTP": [25, 587], "TLS": [443], "ICMP": [], "ARP": [],
}
DNS_QUERIES = [
    "google.com", "cloudflare.com", "github.com", "amazonaws.com",
    "microsoft.com", "apple.com", "akamai.net", "fastly.net",
    "reddit.com", "stackoverflow.com", "cdn.jsdelivr.net",
]
HTTP_HOSTS = [
    "api.github.com", "www.google.com", "cdn.cloudflare.com",
    "s3.amazonaws.com", "fonts.googleapis.com", "analytics.google.com",
]
SURICATA_SIGS = [
    ("ET SCAN Nmap Scripting Engine", 2, "Attempted Information Leak"),
    ("ET POLICY PE EXE or DLL Windows file download HTTP", 2, "Potential Corporate Privacy Violation"),
    ("ET DNS Query to a *.pw domain", 3, "Potentially Bad Traffic"),
    ("ET TROJAN Possible CobaltStrike Beacon", 1, "A Network Trojan was detected"),
    ("ET INFO TLS Handshake Failure", 3, "Potentially Bad Traffic"),
    ("GPL ATTACK_RESPONSE id check returned root", 1, "Potentially Bad Traffic"),
    ("ET SCAN Potential SSH Scan", 2, "Attempted Information Leak"),
    ("ET INFO Observed DNS Query to .onion proxy Domain", 2, "Potentially Bad Traffic"),
]


def rand_ip(public_chance=0.35):
    if random.random() < public_chance:
        return random.choice(PUBLIC_IPS)
    return random.choice(PRIVATE_IPS)


def make_packet():
    proto = random.choice(PROTOCOLS)
    src = rand_ip()
    dst = rand_ip(public_chance=0.55)
    ports = PORT_MAP.get(proto, [random.randint(1024, 65535)])
    sport = random.randint(1024, 65535)
    dport = random.choice(ports) if ports else None

    extra = {}
    if proto == "DNS":
        extra["dns_query"] = random.choice(DNS_QUERIES)
    elif proto in ("HTTP", "HTTPS"):
        extra["http_host"] = random.choice(HTTP_HOSTS)
        extra["http_method"] = random.choice(["GET", "POST", "HEAD"])
        extra["http_path"] = random.choice(["/", "/api/v1/data", "/cdn/asset.js", "/health"])

    return {
        "timestamp":   datetime.now(timezone.utc).isoformat(),
        "src_ip":      src,
        "dst_ip":      dst,
        "src_port":    sport,
        "dst_port":    dport,
        "protocol":    proto,
        "length":      random.randint(64, 1514),
        "ttl":         random.choice([64, 128, 255]),
        "flags":       random.choice(TCP_FLAGS) if proto == "TCP" else None,
        "payload_len": random.randint(0, 1400),
        "summary":     f"{proto} {src}:{sport} > {dst}:{dport}",
        "geo_src":     None,
        "geo_dst":     None,
        "extra":       extra,
    }


def make_alert():
    sig, severity, category = random.choice(SURICATA_SIGS)
    src = rand_ip()
    dst = rand_ip(public_chance=0.6)
    proto = random.choice(["TCP", "UDP"])
    return {
        "event_type": "alert",
        "timestamp":  datetime.now(timezone.utc).isoformat(),
        "severity":   severity,
        "signature":  sig,
        "sig_id":     random.randint(1000000, 9999999),
        "category":   category,
        "src_ip":     src,
        "dst_ip":     dst,
        "src_port":   random.randint(1024, 65535),
        "dst_port":   random.choice([80, 443, 22, 53]),
        "protocol":   proto,
        "action":     "allowed",
        "flow_id":    str(random.randint(10**15, 10**16)),
    }


def make_dns_event():
    return {
        "event_type": "dns",
        "timestamp":  datetime.now(timezone.utc).isoformat(),
        "src_ip":     random.choice(PRIVATE_IPS),
        "dst_ip":     "8.8.8.8",
        "src_port":   random.randint(1024, 65535),
        "dst_port":   53,
        "protocol":   "UDP",
        "dns_type":   "query",
        "dns_query":  random.choice(DNS_QUERIES),
        "dns_qtype":  random.choice(["A", "AAAA", "MX", "TXT", "CNAME"]),
        "flow_id":    str(random.randint(10**15, 10**16)),
    }


async def run():
    print(f"Connecting to {WS_URL} …")
    try:
        async with websockets.connect(WS_URL) as ws:
            print("Connected — sending test traffic (Ctrl+C to stop)\n")
            tick = 0
            while True:
                tick += 1
                batch_size = random.randint(5, 25)
                packets = [make_packet() for _ in range(batch_size)]
                await ws.send(json.dumps({"type": "packets", "data": packets}))

                # Occasional alert
                if tick % 8 == 0:
                    alert = make_alert()
                    await ws.send(json.dumps({"type": "alert", "data": alert}))
                    print(f"  [alert] {alert['signature'][:60]}")

                # Occasional DNS event
                if tick % 4 == 0:
                    dns = make_dns_event()
                    await ws.send(json.dumps({"type": "suricata", "data": dns}))

                print(f"  [{tick:04d}] sent {batch_size} packets", end="\r")
                await asyncio.sleep(random.uniform(0.3, 0.8))
    except ConnectionRefusedError:
        print("\nCould not connect — make sure the backend is running:")
        print("  uvicorn backend.main:app --port 8000")
    except KeyboardInterrupt:
        print("\nStopped.")


if __name__ == "__main__":
    asyncio.run(run())
