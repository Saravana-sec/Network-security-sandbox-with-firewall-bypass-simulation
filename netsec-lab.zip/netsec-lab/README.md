# NetSec Lab — SOC Analyst Dashboard

A production-quality, real-time network monitoring dashboard for your WSL2 home lab.
Built with FastAPI, Scapy, Suricata, React, and WebSockets.

---

## What it does

| Feature | Details |
|---|---|
| **Live packet capture** | Scapy on your real WSL2 NIC — all traffic observed passively |
| **Protocol analysis** | TCP, UDP, DNS, HTTP, HTTPS, SSH, ICMP, ARP, TLS and more |
| **Suricata IDS alerts** | Tails `eve.json` live — alert, dns, http, tls, flow events |
| **Real-time WebSocket** | Dashboard updates without polling |
| **Traffic statistics** | Packets/s, Mbps, protocol breakdown, top talkers, top ports |
| **DNS / HTTP logging** | Top queries and hosts from your own traffic |
| **Packet history** | Ring-buffered in SQLite — survives backend restarts |
| **CSV export** | Download filtered packet captures |
| **GeoIP** | Optional MaxMind GeoLite2 integration |

---

## Prerequisites

- **Windows 10/11** with **WSL2** running **Ubuntu 22.04+**
- Python 3.11+
- Node.js 18+
- sudo access (raw socket capture requires root)

---

## Quick Start

### 1. Clone / place the project

```bash
# In WSL2 terminal
cd ~
# If you downloaded the zip, extract it here
# Your project root is ~/netsec-lab/
```

### 2. Run setup (one time only)

```bash
cd ~/netsec-lab
bash scripts/setup.sh
```

This installs all system packages, Suricata, Python deps, and frontend npm packages.
It auto-detects your WSL2 network interface.

### 3. Start Suricata (Terminal 1)

```bash
# Check which interface was detected
ip route show default
# Should show something like: default via 172.x.x.x dev eth0

sudo suricata -c /etc/suricata/suricata.yaml -i eth0 -D
# -D runs as daemon; check /var/log/suricata/suricata.log for status
```

Verify it's running:
```bash
sudo tail -f /var/log/suricata/eve.json
# Should show JSON events as traffic flows through
```

### 4. Start the backend (Terminal 2)

Packet capture requires root to open raw sockets:

```bash
cd ~/netsec-lab
source .venv/bin/activate

# Run as root (required for Scapy raw socket):
sudo .venv/bin/uvicorn backend.main:app \
  --host 0.0.0.0 \
  --port 8000 \
  --reload
```

Verify:
```bash
curl http://localhost:8000/health
# {"status":"ok"}
```

### 5. Start the frontend (Terminal 3)

```bash
cd ~/netsec-lab/frontend
npm run dev
```

### 6. Open in your browser

```
http://localhost:5173
```

---

## Testing without root / without a live NIC

Use the traffic generator to push realistic fake data into the WebSocket:

```bash
# Backend must be running first
source .venv/bin/activate
python scripts/generate_test_traffic.py
```

This sends realistic packet batches, Suricata alerts, and DNS events directly
into the WebSocket — every chart and table in the UI will populate immediately.
No root required, no NIC needed.

---

## Configuration

Edit `.env` in the project root:

```env
# Network interface (run `ip link show` to list yours)
DEFAULT_INTERFACE=eth0

# Optional BPF filter — leave blank to capture everything
# Examples:
#   CAPTURE_FILTER=tcp port 443
#   CAPTURE_FILTER=not port 22
#   CAPTURE_FILTER=host 192.168.1.1
CAPTURE_FILTER=

# Suricata eve.json path
SURICATA_EVE_LOG=/var/log/suricata/eve.json
SURICATA_ENABLED=true

# GeoIP — see below
GEOIP_ENABLED=false
GEOIP_DB_PATH=data/GeoLite2-City.mmdb
```

---

## Enabling GeoIP

1. Register free at https://dev.maxmind.com/geoip/geolite2-free-geolocation-data
2. Download **GeoLite2-City.mmdb**
3. Place it at `netsec-lab/data/GeoLite2-City.mmdb`
4. Set `GEOIP_ENABLED=true` in `.env`
5. Restart the backend

---

## BPF Filter Examples

Set in `.env` or via the UI capture controls.

| Filter | Effect |
|---|---|
| *(blank)* | Capture all traffic |
| `tcp` | TCP only |
| `tcp port 443` | HTTPS only |
| `not port 22` | Exclude SSH |
| `host 192.168.1.1` | Only traffic to/from one host |
| `tcp and not port 22 and not port 443` | TCP excluding SSH and HTTPS |
| `udp port 53` | DNS queries only |
| `src net 192.168.0.0/16` | Only from private LAN |

---

## Project Structure

```
netsec-lab/
├── backend/
│   ├── main.py                  # FastAPI app entry point
│   ├── config.py                # Settings (reads .env)
│   ├── database.py              # SQLAlchemy async setup
│   ├── models/
│   │   ├── packet.py            # Packet ORM model
│   │   └── alert.py             # Alert ORM model
│   ├── routers/
│   │   ├── capture.py           # /capture/* — start/stop NIC capture
│   │   ├── alerts.py            # /alerts/* — paginated Suricata events
│   │   ├── analysis.py          # /analysis/* — stats, timeseries, top-N
│   │   └── ws.py                # /ws/live — WebSocket broadcaster
│   └── services/
│       ├── capture_service.py   # Scapy live packet capture (thread)
│       ├── suricata_service.py  # eve.json tail (async task)
│       ├── stats_service.py     # In-memory rolling stats
│       ├── db_service.py        # SQLite persistence (batched writes)
│       ├── geoip_service.py     # MaxMind GeoLite2 lookup
│       └── ws_manager.py        # WebSocket connection pool
├── frontend/
│   ├── src/
│   │   ├── App.jsx              # Root router + shared WS state
│   │   ├── api.js               # Axios REST client
│   │   ├── hooks/
│   │   │   ├── useWebSocket.js  # WS client with auto-reconnect
│   │   │   └── usePackets.js    # Ring-buffered packet state
│   │   ├── components/
│   │   │   ├── Layout.jsx       # Sidebar + topbar shell
│   │   │   ├── StatCard.jsx
│   │   │   ├── LiveChart.jsx    # Recharts area chart
│   │   │   ├── ProtocolPieChart.jsx
│   │   │   ├── TopTalkersTable.jsx
│   │   │   ├── CaptureControls.jsx
│   │   │   ├── PacketRow.jsx
│   │   │   └── AlertRow.jsx
│   │   └── pages/
│   │       ├── Dashboard.jsx    # Overview with live stats
│   │       ├── Packets.jsx      # Live packet table + filter + export
│   │       ├── Alerts.jsx       # Suricata alerts with detail drawer
│   │       ├── Analysis.jsx     # Deep traffic breakdown charts
│   │       └── GeoMap.jsx       # Geo IP table (map optional)
│   ├── package.json
│   ├── vite.config.js
│   └── index.html
├── scripts/
│   ├── setup.sh                 # One-shot WSL2 environment setup
│   └── generate_test_traffic.py # UI testing without live capture
├── suricata-config/
│   └── suricata.yaml            # Full Suricata config for WSL2
├── data/                        # Place GeoLite2-City.mmdb here
├── requirements.txt
└── .env                         # Your local config (edit this)
```

---

## API Reference

```
GET  /health                         Health check
GET  /capture/interfaces             List available NICs
POST /capture/start                  Start packet capture
POST /capture/stop                   Stop packet capture
GET  /capture/status                 Capture status + stats

GET  /alerts/?page=1&page_size=50    Paginated alerts
GET  /alerts/summary                 Severity / sig breakdown
GET  /alerts/{id}                    Single alert detail

GET  /analysis/stats                 Live in-memory snapshot
GET  /analysis/timeseries?metric=pps Pps or Mbps time-series
GET  /analysis/protocols             Protocol breakdown
GET  /analysis/top-talkers           Top IPs and ports
GET  /analysis/dns                   Top DNS queries
GET  /analysis/http                  Top HTTP hosts

WS   /ws/live                        Live packet + alert stream
```

---

## Troubleshooting

**"Operation not permitted" on capture start**
→ Backend must run as root: `sudo .venv/bin/uvicorn ...`

**Suricata not writing to eve.json**
→ Check: `sudo tail -20 /var/log/suricata/suricata.log`
→ Ensure the interface in `suricata.yaml` matches your actual NIC

**No packets appearing**
→ Verify your interface: `ip link show` — WSL2 is usually `eth0`
→ Try a BPF filter of just `tcp` to confirm it works, then clear it

**Frontend can't reach backend**
→ Check backend is listening: `curl http://localhost:8000/health`
→ Ensure CORS origins in `config.py` include `http://localhost:5173`

**WebSocket disconnected constantly**
→ Check the browser console; the client auto-reconnects every 2.5s
→ Verify backend is running and not crashing on startup

---

## Dependencies

### Backend
| Package | Purpose |
|---|---|
| fastapi | API framework |
| uvicorn | ASGI server |
| scapy | Packet capture |
| sqlalchemy + aiosqlite | Async SQLite ORM |
| pydantic-settings | Config from .env |
| geoip2 | MaxMind GeoIP (optional) |

### Frontend
| Package | Purpose |
|---|---|
| react 18 | UI |
| react-router-dom | Client-side routing |
| recharts | Charts |
| axios | HTTP client |
| lucide-react | Icons |
| vite | Build tool |
