import React, { useState, useCallback } from 'react'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Layout from './components/Layout'
import Dashboard from './pages/Dashboard'
import Packets from './pages/Packets'
import Alerts from './pages/Alerts'
import Analysis from './pages/Analysis'
import GeoMap from './pages/GeoMap'
import { useWebSocket } from './hooks/useWebSocket'
import { usePackets } from './hooks/usePackets'

export default function App() {
  const { packets, addPackets, clearPackets } = usePackets()
  const [alerts, setAlerts]   = useState([])
  const [stats, setStats]     = useState(null)

  const onPackets = useCallback((incoming) => {
    addPackets(incoming)
  }, [addPackets])

  const onAlert = useCallback((alert) => {
    setAlerts(prev => [alert, ...prev].slice(0, 500))
  }, [])

  const onStats = useCallback((s) => {
    setStats(s)
  }, [])

  const { connected, reconnecting } = useWebSocket({ onPackets, onAlert, onStats })

  return (
    <BrowserRouter>
      <Layout connected={connected} reconnecting={reconnecting}>
        <Routes>
          <Route path="/"         element={<Dashboard stats={stats} alerts={alerts} connected={connected} />} />
          <Route path="/packets"  element={<Packets packets={packets} clearPackets={clearPackets} />} />
          <Route path="/alerts"   element={<Alerts liveAlerts={alerts} />} />
          <Route path="/analysis" element={<Analysis />} />
          <Route path="/geo"      element={<GeoMap />} />
        </Routes>
      </Layout>
    </BrowserRouter>
  )
}
