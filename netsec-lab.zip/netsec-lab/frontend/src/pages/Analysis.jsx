import React, { useEffect, useState, useCallback, useRef } from 'react'
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  CartesianGrid, Cell
} from 'recharts'
import LiveChart from '../components/LiveChart'
import TopTalkersTable from '../components/TopTalkersTable'
import { getTimeseries, getProtocols, getTopTalkers, getDNS, getHTTP } from '../api'

const COLORS = ['#00d4ff','#00e676','#ffa726','#ff4458','#b06afc',
                 '#26c6da','#66bb6a','#ef5350','#ab47bc','#8d6e63']

const CustomBarTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null
  return (
    <div style={{
      background:'var(--bg3)', border:'1px solid var(--border2)',
      borderRadius:4, padding:'6px 10px',
      fontFamily:'var(--mono)', fontSize:11,
    }}>
      <div style={{ color:'var(--muted)', marginBottom:2 }}>{label}</div>
      <div style={{ color:'var(--accent)' }}>{payload[0].value.toLocaleString()}</div>
    </div>
  )
}

function Section({ title, children }) {
  return (
    <div style={{
      background:'var(--bg2)', border:'1px solid var(--border)',
      borderRadius:6, padding:'12px 14px',
    }}>
      <div style={{
        fontSize:10, color:'var(--muted)', textTransform:'uppercase',
        letterSpacing:'0.08em', marginBottom:12,
      }}>{title}</div>
      {children}
    </div>
  )
}

export default function Analysis() {
  const [ppsHistory, setPpsHistory]   = useState([])
  const [mbpsHistory, setMbpsHistory] = useState([])
  const [protocols, setProtocols]     = useState([])
  const [topIPs, setTopIPs]           = useState([])
  const [topPorts, setTopPorts]       = useState([])
  const [dns, setDns]                 = useState([])
  const [http, setHttp]               = useState([])
  const pollRef = useRef(null)

  const fetchAll = useCallback(async () => {
    try {
      const [pps, mbps, proto, talkers, dnsRes, httpRes] = await Promise.all([
        getTimeseries({ metric:'pps',  seconds:60 }),
        getTimeseries({ metric:'mbps', seconds:60 }),
        getProtocols(),
        getTopTalkers(),
        getDNS(),
        getHTTP(),
      ])
      setPpsHistory(pps.data.data     || [])
      setMbpsHistory(mbps.data.data   || [])
      setProtocols(proto.data.protocols || [])
      setTopIPs(talkers.data.top_ips  || [])
      setTopPorts(talkers.data.top_ports || [])
      setDns(dnsRes.data.top_dns_queries || [])
      setHttp(httpRes.data.top_http_hosts || [])
    } catch (_) {}
  }, [])

  useEffect(() => {
    fetchAll()
    pollRef.current = setInterval(fetchAll, 4000)
    return () => clearInterval(pollRef.current)
  }, [fetchAll])

  const protoBarData = protocols.slice(0,10).map((p, i) => ({
    name: p.protocol,
    count: p.count,
    pct: p.pct,
    fill: COLORS[i % COLORS.length],
  }))

  const portBarData = topPorts.slice(0,10).map((p, i) => ({
    name: p.key,
    count: p.count,
    fill: COLORS[i % COLORS.length],
  }))

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:14 }}>

      {/* Timeseries */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:12 }}>
        <LiveChart data={ppsHistory}  unit="pps"  color="var(--accent)" title="Packets / Second (60s)" />
        <LiveChart data={mbpsHistory} unit="Mbps" color="var(--green)"  title="Throughput Mbps (60s)" />
      </div>

      {/* Protocol bar chart */}
      <Section title="Protocol Distribution">
        {protoBarData.length === 0
          ? <Empty />
          : <ResponsiveContainer width="100%" height={180}>
              <BarChart data={protoBarData} margin={{ top:4, right:4, left:-20, bottom:0 }}>
                <CartesianGrid strokeDasharray="3 8" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="name"
                  tick={{ fontFamily:'var(--mono)', fontSize:10, fill:'var(--text)' }}
                  tickLine={false} axisLine={false} />
                <YAxis
                  tick={{ fontFamily:'var(--mono)', fontSize:9, fill:'var(--muted)' }}
                  tickLine={false} axisLine={false} />
                <Tooltip content={<CustomBarTooltip />} cursor={{ fill:'rgba(255,255,255,0.04)' }} />
                <Bar dataKey="count" radius={[3,3,0,0]} isAnimationActive={false}>
                  {protoBarData.map((e, i) => <Cell key={i} fill={e.fill} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
        }
        {protoBarData.length > 0 && (
          <div style={{ display:'flex', flexWrap:'wrap', gap:6, marginTop:10 }}>
            {protoBarData.map((p, i) => (
              <div key={i} style={{
                fontFamily:'var(--mono)', fontSize:10,
                display:'flex', alignItems:'center', gap:5,
              }}>
                <div style={{ width:7, height:7, borderRadius:'50%', background:p.fill }} />
                <span style={{ color:'var(--text)' }}>{p.name}</span>
                <span style={{ color:'var(--muted)' }}>{p.pct}%</span>
              </div>
            ))}
          </div>
        )}
      </Section>

      {/* Port distribution */}
      <Section title="Top Destination Ports">
        {portBarData.length === 0
          ? <Empty />
          : <ResponsiveContainer width="100%" height={160}>
              <BarChart data={portBarData} margin={{ top:4, right:4, left:-20, bottom:0 }}>
                <CartesianGrid strokeDasharray="3 8" stroke="rgba(255,255,255,0.04)" />
                <XAxis dataKey="name"
                  tick={{ fontFamily:'var(--mono)', fontSize:10, fill:'var(--text)' }}
                  tickLine={false} axisLine={false} />
                <YAxis
                  tick={{ fontFamily:'var(--mono)', fontSize:9, fill:'var(--muted)' }}
                  tickLine={false} axisLine={false} />
                <Tooltip content={<CustomBarTooltip />} cursor={{ fill:'rgba(255,255,255,0.04)' }} />
                <Bar dataKey="count" radius={[3,3,0,0]} isAnimationActive={false}>
                  {portBarData.map((e, i) => <Cell key={i} fill={e.fill} />)}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
        }
      </Section>

      {/* Top talkers + DNS + HTTP */}
      <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr 1fr', gap:12 }}>
        <TopTalkersTable data={topIPs}  title="Top Source IPs"   keyLabel="IP" />
        <TopTalkersTable data={dns}     title="Top DNS Queries"  keyLabel="Query" />
        <TopTalkersTable data={http}    title="Top HTTP Hosts"   keyLabel="Host" />
      </div>
    </div>
  )
}

function Empty() {
  return (
    <div style={{ textAlign:'center', color:'var(--muted)', fontFamily:'var(--mono)', fontSize:12, padding:'24px 0' }}>
      No data yet — start capture to see traffic analysis
    </div>
  )
}
