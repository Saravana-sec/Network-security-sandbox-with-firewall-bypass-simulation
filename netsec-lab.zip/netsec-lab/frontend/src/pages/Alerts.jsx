import React, { useEffect, useState, useCallback } from 'react'
import AlertRow from '../components/AlertRow'
import { getAlerts, getAlertsSummary } from '../api'
import { RefreshCw, ChevronLeft, ChevronRight, X } from 'lucide-react'

const TH = ({ children, right }) => (
  <th style={{
    textAlign: right ? 'right' : 'left',
    fontFamily: 'var(--mono)', fontSize: 9,
    color: 'var(--muted)', fontWeight: 400,
    textTransform: 'uppercase', letterSpacing: '0.07em',
    padding: '6px 8px', borderBottom: '1px solid var(--border)',
    position: 'sticky', top: 0, background: 'var(--bg2)', zIndex: 1,
  }}>{children}</th>
)

export default function Alerts({ liveAlerts }) {
  const [items, setItems]         = useState([])
  const [total, setTotal]         = useState(0)
  const [page, setPage]           = useState(1)
  const [summary, setSummary]     = useState(null)
  const [loading, setLoading]     = useState(false)
  const [selected, setSelected]   = useState(null)
  const [eventType, setEventType] = useState('')
  const PAGE_SIZE = 50

  const fetch_ = useCallback(async () => {
    setLoading(true)
    try {
      const params = { page, page_size: PAGE_SIZE }
      if (eventType) params.event_type = eventType
      const [alertsRes, sumRes] = await Promise.all([
        getAlerts(params),
        getAlertsSummary(),
      ])
      setItems(alertsRes.data.items || [])
      setTotal(alertsRes.data.total || 0)
      setSummary(sumRes.data)
    } catch (_) {}
    finally { setLoading(false) }
  }, [page, eventType])

  useEffect(() => { fetch_() }, [fetch_])

  // Merge live alerts at top of list
  const merged = [
    ...liveAlerts.filter(a => a.event_type === 'alert' || !eventType || a.event_type === eventType),
    ...items,
  ].slice(0, 200)

  const pages = Math.ceil(total / PAGE_SIZE)

  const SEV_COLORS = { 1: 'var(--danger)', 2: 'var(--warn)', 3: 'var(--green)' }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12, height: '100%' }}>

      {/* Summary cards */}
      {summary && (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4,1fr)', gap: 10 }}>
          {summary.severity_breakdown.map(s => (
            <div key={s.severity} style={{
              background: 'var(--bg2)', border: `1px solid ${SEV_COLORS[s.severity] || 'var(--border)'}33`,
              borderRadius: 6, padding: '10px 14px',
            }}>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 20, fontWeight: 600, color: SEV_COLORS[s.severity] || 'var(--text)' }}>
                {s.count}
              </div>
              <div style={{ fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.07em', marginTop: 3 }}>
                {s.severity === 1 ? 'High' : s.severity === 2 ? 'Medium' : s.severity === 3 ? 'Low' : `Sev ${s.severity}`}
              </div>
            </div>
          ))}
          {summary.event_type_counts.slice(0, 4 - summary.severity_breakdown.length).map(e => (
            <div key={e.event_type} style={{
              background: 'var(--bg2)', border: '1px solid var(--border)',
              borderRadius: 6, padding: '10px 14px',
            }}>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 20, fontWeight: 600, color: 'var(--accent)' }}>
                {e.count}
              </div>
              <div style={{ fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.07em', marginTop: 3 }}>
                {e.event_type}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Top signatures */}
      {summary?.top_signatures?.length > 0 && (
        <div style={{
          background: 'var(--bg2)', border: '1px solid var(--border)',
          borderRadius: 6, padding: '10px 14px',
        }}>
          <div style={{ fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 8 }}>
            Top Triggered Signatures
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {summary.top_signatures.slice(0, 8).map((s, i) => (
              <div key={i} style={{
                fontFamily: 'var(--mono)', fontSize: 10,
                background: 'var(--bg3)', border: '1px solid var(--border2)',
                borderRadius: 4, padding: '3px 8px', color: 'var(--text)',
              }}>
                {s.signature || 'unknown'}
                <span style={{ color: 'var(--accent)', marginLeft: 6 }}>{s.count}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Toolbar */}
      <div style={{
        display: 'flex', gap: 8, alignItems: 'center',
        background: 'var(--bg2)', border: '1px solid var(--border)',
        borderRadius: 6, padding: '8px 12px',
      }}>
        <select
          value={eventType}
          onChange={e => { setEventType(e.target.value); setPage(1) }}
          style={selStyle}
        >
          <option value="">All event types</option>
          <option value="alert">alert</option>
          <option value="dns">dns</option>
          <option value="http">http</option>
          <option value="tls">tls</option>
          <option value="flow">flow</option>
        </select>

        <span style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--muted)', marginLeft: 4 }}>
          {total.toLocaleString()} total
        </span>

        <button onClick={fetch_} style={iconBtn('var(--muted)')}>
          <RefreshCw size={13} style={{ animation: loading ? 'spin 1s linear infinite' : 'none' }} />
          Refresh
        </button>
      </div>

      {/* Table */}
      <div style={{ flex: 1, overflow: 'auto', background: 'var(--bg2)', border: '1px solid var(--border)', borderRadius: 6 }}>
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <TH>Time</TH>
              <TH>Type</TH>
              <TH>Severity</TH>
              <TH>Signature / Event</TH>
              <TH>Source</TH>
              <TH></TH>
              <TH>Destination</TH>
              <TH>Proto</TH>
            </tr>
          </thead>
          <tbody>
            {merged.length === 0 ? (
              <tr><td colSpan={8} style={{
                textAlign: 'center', color: 'var(--muted)',
                fontFamily: 'var(--mono)', fontSize: 12, padding: 32,
              }}>
                {loading ? 'Loading…' : 'No alerts yet — start capture and wait for Suricata events'}
              </td></tr>
            ) : merged.map((a, i) => (
              <AlertRow key={a.id ?? `live-${i}`} alert={a} onClick={setSelected} />
            ))}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {pages > 1 && (
        <div style={{ display: 'flex', gap: 8, alignItems: 'center', justifyContent: 'flex-end' }}>
          <button onClick={() => setPage(p => Math.max(1, p-1))} disabled={page === 1} style={iconBtn('var(--muted)')}>
            <ChevronLeft size={13} />
          </button>
          <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--muted)' }}>
            {page} / {pages}
          </span>
          <button onClick={() => setPage(p => Math.min(pages, p+1))} disabled={page === pages} style={iconBtn('var(--muted)')}>
            <ChevronRight size={13} />
          </button>
        </div>
      )}

      {/* Detail drawer */}
      {selected && (
        <div style={{
          position: 'fixed', right: 0, top: 0, bottom: 0, width: 400,
          background: 'var(--bg1)', borderLeft: '1px solid var(--border2)',
          display: 'flex', flexDirection: 'column', zIndex: 100,
          boxShadow: '-8px 0 24px rgba(0,0,0,0.5)',
        }}>
          <div style={{
            display: 'flex', alignItems: 'center', padding: '10px 14px',
            borderBottom: '1px solid var(--border)', gap: 8,
          }}>
            <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--accent)', flex: 1 }}>
              Alert Detail
            </span>
            <button onClick={() => setSelected(null)} style={{ background: 'none', border: 'none', cursor: 'pointer', color: 'var(--muted)' }}>
              <X size={15} />
            </button>
          </div>
          <div style={{ flex: 1, overflow: 'auto', padding: 14 }}>
            {Object.entries(selected).filter(([, v]) => v != null && v !== '').map(([k, v]) => (
              <div key={k} style={{ marginBottom: 8 }}>
                <div style={{ fontFamily: 'var(--mono)', fontSize: 9, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 2 }}>
                  {k}
                </div>
                <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--text)', wordBreak: 'break-all' }}>
                  {typeof v === 'object' ? JSON.stringify(v, null, 2) : String(v)}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  )
}

const selStyle = {
  background: 'var(--bg3)', border: '1px solid var(--border2)',
  color: 'var(--text)', fontFamily: 'var(--mono)', fontSize: 11,
  padding: '4px 8px', borderRadius: 4, cursor: 'pointer',
}
const iconBtn = (color) => ({
  display: 'flex', alignItems: 'center', gap: 5,
  background: 'transparent', border: `1px solid ${color}44`,
  color, fontFamily: 'var(--mono)', fontSize: 10,
  padding: '4px 10px', borderRadius: 4, cursor: 'pointer',
  letterSpacing: '0.06em',
})
