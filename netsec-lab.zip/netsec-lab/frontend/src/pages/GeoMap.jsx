import React, { useEffect, useState, useCallback, useRef } from 'react'
import { Globe, Info } from 'lucide-react'
import { getTopTalkers } from '../api'

// Simple SVG world map approximation using geo data table
// For a full map, drop in react-simple-maps + world-atlas topo once npm installed
export default function GeoMap() {
  const [topIPs, setTopIPs]   = useState([])
  const [loading, setLoading] = useState(false)
  const pollRef = useRef(null)

  const fetchData = useCallback(async () => {
    setLoading(true)
    try {
      const r = await getTopTalkers()
      setTopIPs(r.data.top_ips || [])
    } catch (_) {}
    finally { setLoading(false) }
  }, [])

  useEffect(() => {
    fetchData()
    pollRef.current = setInterval(fetchData, 5000)
    return () => clearInterval(pollRef.current)
  }, [fetchData])

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>

      {/* Info banner */}
      <div style={{
        background: 'rgba(0,212,255,0.07)', border: '1px solid rgba(0,212,255,0.2)',
        borderRadius: 6, padding: '10px 14px',
        display: 'flex', alignItems: 'center', gap: 10,
      }}>
        <Info size={14} color="var(--accent)" />
        <span style={{ fontSize: 12, color: 'var(--text)' }}>
          Full geo mapping requires the free{' '}
          <strong style={{ color: 'var(--accent)' }}>MaxMind GeoLite2-City.mmdb</strong>.
          Download it from{' '}
          <a href="https://dev.maxmind.com/geoip/geolite2-free-geolocation-data"
            target="_blank" rel="noreferrer"
            style={{ color: 'var(--accent)' }}>
            maxmind.com
          </a>
          , place it in <code style={{ fontFamily: 'var(--mono)', color: 'var(--purple)' }}>data/GeoLite2-City.mmdb</code>,
          and set <code style={{ fontFamily: 'var(--mono)', color: 'var(--purple)' }}>GEOIP_ENABLED=true</code> in <code style={{ fontFamily: 'var(--mono)', color: 'var(--purple)' }}>.env</code>.
        </span>
      </div>

      {/* Placeholder world map */}
      <div style={{
        background: 'var(--bg2)', border: '1px solid var(--border)',
        borderRadius: 6, padding: 0, overflow: 'hidden', position: 'relative',
      }}>
        <div style={{
          fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase',
          letterSpacing: '0.08em', padding: '12px 14px 0',
        }}>
          World Traffic Map
        </div>
        <div style={{
          height: 320, display: 'flex', alignItems: 'center', justifyContent: 'center',
          flexDirection: 'column', gap: 12,
        }}>
          <Globe size={64} color="var(--border2)" strokeWidth={0.8} />
          <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--muted)', textAlign: 'center' }}>
            Install <span style={{ color: 'var(--text)' }}>react-simple-maps</span> and configure GeoIP<br />
            to enable the interactive world traffic map
          </div>
          <code style={{
            fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--accent)',
            background: 'var(--bg3)', padding: '4px 10px', borderRadius: 4,
          }}>
            npm install react-simple-maps world-atlas
          </code>
        </div>
      </div>

      {/* IP table — works without GeoIP */}
      <div style={{
        background: 'var(--bg2)', border: '1px solid var(--border)',
        borderRadius: 6, padding: '12px 14px',
      }}>
        <div style={{
          fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase',
          letterSpacing: '0.08em', marginBottom: 10,
        }}>
          Top Source IPs by Packet Volume
        </div>
        {topIPs.length === 0 ? (
          <div style={{ color: 'var(--muted)', fontFamily: 'var(--mono)', fontSize: 12, padding: '16px 0', textAlign: 'center' }}>
            {loading ? 'Loading…' : 'No traffic captured yet'}
          </div>
        ) : (
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                {['Rank', 'IP Address', 'Packets', 'Share'].map(h => (
                  <th key={h} style={{
                    textAlign: 'left', fontFamily: 'var(--mono)', fontSize: 9,
                    color: 'var(--muted)', fontWeight: 400,
                    textTransform: 'uppercase', letterSpacing: '0.07em',
                    paddingBottom: 6, borderBottom: '1px solid var(--border)',
                  }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {topIPs.map((row, i) => {
                const max = topIPs[0]?.count || 1
                const pct = ((row.count / max) * 100).toFixed(1)
                return (
                  <tr key={i} style={{ borderBottom: '0.5px solid rgba(255,255,255,0.04)' }}>
                    <td style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--muted)', padding: '5px 8px 5px 0' }}>
                      #{i + 1}
                    </td>
                    <td style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--text)', padding: '5px 8px' }}>
                      {row.key}
                    </td>
                    <td style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--accent)', padding: '5px 8px' }}>
                      {row.count.toLocaleString()}
                    </td>
                    <td style={{ padding: '5px 8px', minWidth: 120 }}>
                      <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                        <div style={{ flex: 1, height: 4, background: 'var(--bg3)', borderRadius: 2, overflow: 'hidden' }}>
                          <div style={{
                            width: `${pct}%`, height: '100%',
                            background: 'var(--accent)', borderRadius: 2,
                            transition: 'width 0.4s ease',
                          }} />
                        </div>
                        <span style={{ fontFamily: 'var(--mono)', fontSize: 9, color: 'var(--muted)', width: 36 }}>
                          {pct}%
                        </span>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  )
}
