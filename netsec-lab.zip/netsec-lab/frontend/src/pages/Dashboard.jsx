import React, { useEffect, useState, useCallback, useRef } from 'react'
import { Wifi, Package, ShieldAlert, Activity, Database } from 'lucide-react'
import StatCard from '../components/StatCard'
import LiveChart from '../components/LiveChart'
import ProtocolPieChart from '../components/ProtocolPieChart'
import TopTalkersTable from '../components/TopTalkersTable'
import CaptureControls from '../components/CaptureControls'
import { getTimeseries, getProtocols, getTopTalkers } from '../api'

const grid = (cols) => ({
  display: 'grid',
  gridTemplateColumns: cols,
  gap: 12,
})

export default function Dashboard({ stats, alerts, connected }) {
  const [ppsHistory, setPpsHistory]     = useState([])
  const [mbpsHistory, setMbpsHistory]   = useState([])
  const [protocols, setProtocols]       = useState([])
  const [topIPs, setTopIPs]             = useState([])
  const [topPorts, setTopPorts]         = useState([])
  const pollRef = useRef(null)

  const fetchChartData = useCallback(async () => {
    try {
      const [pps, mbps, proto, talkers] = await Promise.all([
        getTimeseries({ metric: 'pps',  seconds: 60 }),
        getTimeseries({ metric: 'mbps', seconds: 60 }),
        getProtocols(),
        getTopTalkers(),
      ])
      setPpsHistory(pps.data.data   || [])
      setMbpsHistory(mbps.data.data || [])
      setProtocols(proto.data.protocols || [])
      setTopIPs(talkers.data.top_ips    || [])
      setTopPorts(talkers.data.top_ports|| [])
    } catch (_) {}
  }, [])

  useEffect(() => {
    fetchChartData()
    pollRef.current = setInterval(fetchChartData, 3000)
    return () => clearInterval(pollRef.current)
  }, [fetchChartData])

  const recentAlerts = alerts.slice(0, 5)
  const highAlerts   = alerts.filter(a => a.severity === 1).length

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>

      {/* Capture Controls */}
      <CaptureControls />

      {/* Stat cards */}
      <div style={grid('repeat(5, 1fr)')}>
        <StatCard
          label="Packets/s"
          value={stats?.pps ?? 0}
          unit="pps"
          color="var(--accent)"
          icon={Activity}
        />
        <StatCard
          label="Throughput"
          value={stats?.mbps ?? 0}
          unit="Mbps"
          color="var(--green)"
          icon={Wifi}
        />
        <StatCard
          label="Total Packets"
          value={(stats?.total_packets ?? 0).toLocaleString()}
          color="var(--text)"
          icon={Package}
        />
        <StatCard
          label="Total Alerts"
          value={stats?.total_alerts ?? 0}
          color={highAlerts > 0 ? 'var(--danger)' : 'var(--warn)'}
          icon={ShieldAlert}
          sub={highAlerts > 0 ? `${highAlerts} high severity` : null}
        />
        <StatCard
          label="Data Captured"
          value={formatBytes(stats?.total_bytes ?? 0)}
          color="var(--purple)"
          icon={Database}
        />
      </div>

      {/* Time-series charts */}
      <div style={grid('1fr 1fr')}>
        <LiveChart data={ppsHistory} unit="pps"  color="var(--accent)" title="Packets / Second" />
        <LiveChart data={mbpsHistory} unit="Mbps" color="var(--green)"  title="Throughput (Mbps)" />
      </div>

      {/* Protocol + talkers */}
      <div style={grid('1fr 1fr 1fr')}>
        <ProtocolPieChart data={protocols} />
        <TopTalkersTable  data={topIPs}   title="Top Source IPs" keyLabel="IP" />
        <TopTalkersTable  data={topPorts} title="Top Dest Ports"  keyLabel="Port" />
      </div>

      {/* Recent alerts */}
      {recentAlerts.length > 0 && (
        <div style={{
          background: 'var(--bg2)', border: '1px solid var(--border)',
          borderRadius: 6, padding: '12px 14px',
        }}>
          <div style={{
            fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase',
            letterSpacing: '0.08em', marginBottom: 10,
          }}>
            Recent Alerts
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr>
                {['Time','Type','Severity','Signature / Event','Src IP'].map(h => (
                  <th key={h} style={{
                    textAlign: 'left', fontFamily: 'var(--mono)',
                    fontSize: 9, color: 'var(--muted)', fontWeight: 400,
                    textTransform: 'uppercase', letterSpacing: '0.07em',
                    paddingBottom: 6, borderBottom: '1px solid var(--border)',
                  }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {recentAlerts.map((a, i) => {
                const sevColor = a.severity === 1 ? 'var(--danger)' : a.severity === 2 ? 'var(--warn)' : 'var(--green)'
                const sevLabel = a.severity === 1 ? 'HIGH' : a.severity === 2 ? 'MED' : 'LOW'
                return (
                  <tr key={i} style={{ borderBottom: '0.5px solid rgba(255,255,255,0.04)' }}>
                    <td style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--muted)', padding: '4px 8px 4px 0' }}>
                      {a.timestamp ? new Date(a.timestamp).toLocaleTimeString([], { hour12: false }) : '—'}
                    </td>
                    <td style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--accent)', padding: '4px 8px' }}>
                      {a.event_type?.toUpperCase()}
                    </td>
                    <td style={{ fontFamily: 'var(--mono)', fontSize: 10, color: sevColor, padding: '4px 8px' }}>
                      {a.severity != null ? sevLabel : '—'}
                    </td>
                    <td style={{
                      fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--text)', padding: '4px 8px',
                      maxWidth: 280, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
                    }}>
                      {a.signature || a.dns_query || a.http_host || '—'}
                    </td>
                    <td style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--text)', padding: '4px 8px' }}>
                      {a.src_ip || '—'}
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

function formatBytes(bytes) {
  if (bytes === 0) return '0 B'
  const k = 1024
  const sizes = ['B', 'KB', 'MB', 'GB']
  const i = Math.floor(Math.log(bytes) / Math.log(k))
  return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i]
}
