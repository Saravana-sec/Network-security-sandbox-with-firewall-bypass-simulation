import React, { useState, useRef, useEffect } from 'react'
import PacketRow from '../components/PacketRow'
import { Trash2, PauseCircle, PlayCircle, Download } from 'lucide-react'

const TH_STYLE = {
  textAlign: 'left', fontFamily: 'var(--mono)', fontSize: 9,
  color: 'var(--muted)', fontWeight: 400, textTransform: 'uppercase',
  letterSpacing: '0.07em', padding: '6px 8px',
  borderBottom: '1px solid var(--border)', whiteSpace: 'nowrap',
  position: 'sticky', top: 0, background: 'var(--bg2)', zIndex: 1,
}

const PROTO_ALL = 'ALL'

export default function Packets({ packets, clearPackets }) {
  const [paused, setPaused]     = useState(false)
  const [filter, setFilter]     = useState('')
  const [proto, setProto]       = useState(PROTO_ALL)
  const [displayed, setDisplayed] = useState([])
  const bottomRef = useRef(null)
  const pausedRef = useRef(false)

  pausedRef.current = paused

  // Update displayed list whenever packets change (unless paused)
  useEffect(() => {
    if (!paused) setDisplayed(packets)
  }, [packets, paused])

  // Auto-scroll to bottom
  useEffect(() => {
    if (!paused) bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [displayed, paused])

  const protocols = ['ALL', ...new Set(packets.map(p => p.protocol).filter(Boolean))]

  const visible = displayed.filter(p => {
    if (proto !== PROTO_ALL && p.protocol !== proto) return false
    if (filter) {
      const f = filter.toLowerCase()
      return (
        p.src_ip?.includes(f) || p.dst_ip?.includes(f) ||
        String(p.src_port).includes(f) || String(p.dst_port).includes(f) ||
        p.protocol?.toLowerCase().includes(f) ||
        p.summary?.toLowerCase().includes(f)
      )
    }
    return true
  })

  const exportCSV = () => {
    const header = 'timestamp,protocol,src_ip,src_port,dst_ip,dst_port,length,flags\n'
    const rows = visible.map(p =>
      [p.timestamp, p.protocol, p.src_ip, p.src_port, p.dst_ip, p.dst_port, p.length, p.flags].join(',')
    ).join('\n')
    const blob = new Blob([header + rows], { type: 'text/csv' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a'); a.href = url; a.download = 'packets.csv'; a.click()
    URL.revokeObjectURL(url)
  }

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 10, height: '100%' }}>

      {/* Toolbar */}
      <div style={{
        display: 'flex', gap: 8, alignItems: 'center',
        background: 'var(--bg2)', border: '1px solid var(--border)',
        borderRadius: 6, padding: '8px 12px', flexWrap: 'wrap',
      }}>
        <input
          value={filter}
          onChange={e => setFilter(e.target.value)}
          placeholder="Filter: IP, port, protocol, summary…"
          style={{
            background: 'var(--bg3)', border: '1px solid var(--border2)',
            color: 'var(--text)', fontFamily: 'var(--mono)', fontSize: 11,
            padding: '4px 8px', borderRadius: 4, outline: 'none', flex: 1, minWidth: 200,
          }}
        />

        <select
          value={proto}
          onChange={e => setProto(e.target.value)}
          style={{
            background: 'var(--bg3)', border: '1px solid var(--border2)',
            color: 'var(--text)', fontFamily: 'var(--mono)', fontSize: 11,
            padding: '4px 8px', borderRadius: 4, cursor: 'pointer',
          }}
        >
          {protocols.map(p => <option key={p} value={p}>{p}</option>)}
        </select>

        <span style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--muted)', marginLeft: 4 }}>
          {visible.length.toLocaleString()} / {packets.length.toLocaleString()} pkts
        </span>

        <button onClick={() => setPaused(p => !p)} style={iconBtn(paused ? 'var(--warn)' : 'var(--muted)')}>
          {paused ? <PlayCircle size={15} /> : <PauseCircle size={15} />}
          {paused ? 'Resume' : 'Pause'}
        </button>

        <button onClick={exportCSV} style={iconBtn('var(--muted)')}>
          <Download size={15} /> CSV
        </button>

        <button onClick={clearPackets} style={iconBtn('var(--danger)')}>
          <Trash2 size={15} /> Clear
        </button>
      </div>

      {/* Table */}
      <div style={{
        flex: 1, overflow: 'auto', background: 'var(--bg2)',
        border: '1px solid var(--border)', borderRadius: 6,
      }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', tableLayout: 'fixed' }}>
          <colgroup>
            <col style={{ width: 80 }} />
            <col style={{ width: 80 }} />
            <col style={{ width: 160 }} />
            <col style={{ width: 14 }} />
            <col style={{ width: 160 }} />
            <col style={{ width: 64 }} />
            <col style={{ width: 80 }} />
            <col style={{ width: 120 }} />
          </colgroup>
          <thead>
            <tr>
              {['Time', 'Proto', 'Source', '', 'Destination', 'Len', 'Flags', 'Geo'].map((h, i) => (
                <th key={i} style={TH_STYLE}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {visible.length === 0 ? (
              <tr><td colSpan={8} style={{
                textAlign: 'center', color: 'var(--muted)', fontFamily: 'var(--mono)',
                fontSize: 12, padding: 32,
              }}>
                {packets.length === 0 ? 'No packets captured yet — start capture above' : 'No packets match filter'}
              </td></tr>
            ) : (
              visible.map((pkt, i) => (
                <PacketRow key={pkt._id ?? i} pkt={pkt} />
              ))
            )}
            <tr><td ref={bottomRef} colSpan={8} /></tr>
          </tbody>
        </table>
      </div>
    </div>
  )
}

const iconBtn = (color) => ({
  display: 'flex', alignItems: 'center', gap: 5,
  background: 'transparent', border: `1px solid ${color}44`,
  color, fontFamily: 'var(--mono)', fontSize: 10,
  padding: '4px 10px', borderRadius: 4, cursor: 'pointer',
  letterSpacing: '0.06em', transition: 'all 0.15s',
})
