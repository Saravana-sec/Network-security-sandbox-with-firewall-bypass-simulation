import { useState, useCallback, useRef } from 'react'

const MAX_PACKETS = 500

export function usePackets() {
  const [packets, setPackets] = useState([])
  const counterRef = useRef(0)

  const addPackets = useCallback((incoming) => {
    setPackets(prev => {
      const next = [...prev, ...incoming.map(p => ({ ...p, _id: counterRef.current++ }))]
      return next.length > MAX_PACKETS ? next.slice(next.length - MAX_PACKETS) : next
    })
  }, [])

  const clearPackets = useCallback(() => setPackets([]), [])

  return { packets, addPackets, clearPackets }
}
