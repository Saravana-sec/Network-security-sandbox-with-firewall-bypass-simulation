import { useEffect, useRef, useCallback, useState } from 'react'

const WS_URL = `ws://${window.location.hostname}:8000/ws/live`
const RECONNECT_DELAY_MS = 2500

export function useWebSocket({ onPackets, onAlert, onStats }) {
  const ws = useRef(null)
  const handlers = useRef({ onPackets, onAlert, onStats })
  const [connected, setConnected] = useState(false)
  const [reconnecting, setReconnecting] = useState(false)
  const reconnectTimer = useRef(null)

  // Keep handlers ref current without restarting the socket
  useEffect(() => {
    handlers.current = { onPackets, onAlert, onStats }
  }, [onPackets, onAlert, onStats])

  const connect = useCallback(() => {
    if (ws.current && ws.current.readyState < 2) return

    const socket = new WebSocket(WS_URL)
    ws.current = socket

    socket.onopen = () => {
      setConnected(true)
      setReconnecting(false)
    }

    socket.onmessage = (evt) => {
      let msg
      try { msg = JSON.parse(evt.data) } catch { return }

      const h = handlers.current
      if (msg.type === 'packets' && h.onPackets) h.onPackets(msg.data)
      else if (msg.type === 'alert' && h.onAlert)   h.onAlert(msg.data)
      else if (msg.type === 'stats' && h.onStats)   h.onStats(msg.data)
      // ping frames ignored
    }

    socket.onclose = () => {
      setConnected(false)
      setReconnecting(true)
      reconnectTimer.current = setTimeout(connect, RECONNECT_DELAY_MS)
    }

    socket.onerror = () => socket.close()
  }, [])

  useEffect(() => {
    connect()
    return () => {
      clearTimeout(reconnectTimer.current)
      ws.current?.close()
    }
  }, [connect])

  const send = useCallback((data) => {
    if (ws.current?.readyState === 1) {
      ws.current.send(JSON.stringify(data))
    }
  }, [])

  return { connected, reconnecting, send }
}
