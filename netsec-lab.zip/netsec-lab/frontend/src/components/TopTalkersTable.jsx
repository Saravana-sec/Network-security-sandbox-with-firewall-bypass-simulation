import React from 'react'

export default function TopTalkersTable({ data = [], title = 'Top IPs', keyLabel = 'IP Address' }) {
  const max = data[0]?.count || 1

  return (
    <div style={{
      background: 'var(--bg2)', border: '1px solid var(--border)',
      borderRadius: 6, padding: '12px 14px',
    }}>
      <div style={{
        fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase',
        letterSpacing: '0.08em', marginBottom: 10,
      }}>
        {title}
      </div>
      {data.length === 0 ? (
        <div style={{ color: 'var(--muted)', fontSize: 12, padding: '12px 0', textAlign: 'center' }}>
          No data yet
        </div>
      ) : (
        <table style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              {[keyLabel, 'Count', 'Bar'].map(h => (
                <th key={h} style={{
                  textAlign: h === 'Count' ? 'right' : 'left',
                  fontFamily: 'var(--mono)', fontSize: 9,
                  color: 'var(--muted)', fontWeight: 400,
                  textTransform: 'uppercase', letterSpacing: '0.07em',
                  paddingBottom: 6, borderBottom: '1px solid var(--border)',
                }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.slice(0, 10).map((row, i) => (
              <tr key={i} style={{ borderBottom: '0.5px solid rgba(255,255,255,0.04)' }}>
                <td style={{
                  fontFamily: 'var(--mono)', fontSize: 11,
                  color: 'var(--text)', padding: '5px 0',
                }}>
                  {row.key}
                </td>
                <td style={{
                  fontFamily: 'var(--mono)', fontSize: 11,
                  color: 'var(--accent)', textAlign: 'right',
                  padding: '5px 8px',
                }}>
                  {row.count.toLocaleString()}
                </td>
                <td style={{ padding: '5px 0', width: 80 }}>
                  <div style={{
                    height: 4, borderRadius: 2,
                    background: 'var(--bg3)', overflow: 'hidden',
                  }}>
                    <div style={{
                      height: '100%', borderRadius: 2,
                      width: `${(row.count / max) * 100}%`,
                      background: 'var(--accent)',
                      transition: 'width 0.4s ease',
                    }} />
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  )
}
