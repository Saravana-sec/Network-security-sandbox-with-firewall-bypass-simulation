import React, { useEffect, useState } from 'react'
import { Play, Square, RefreshCw } from 'lucide-react'
import { getInterfaces, startCapture, stopCapture, getCaptureStatus } from '../api'

export default function CaptureControls({ onStatusChange }) {
  const [ifaces, setIfaces]     = useState([])
  const [iface, setIface]       = useState('eth0')
  const [filter, setFilter]     = useState('')
  const [running, setRunning]   = useState(false)
  const [loading, setLoading]   = useState(false)
  const [error, setError]       = useState(null)

  useEffect(() => {
    getInterfaces()
      .then(r => {
        setIfaces(r.data.interfaces || [])
        if (r.data.interfaces?.length) setIface(r.data.interfaces[0])
      })
      .catch(() => {})

    getCaptureStatus()
      .then(r => setRunning(r.data.capture?.running || false))
      .catch(() => {})
  }, [])

  const handleStart = async () => {
    setLoading(true); setError(null)
    try {
      await startCapture({ interface: iface, bpf_filter: filter })
      setRunning(true)
      onStatusChange?.('started')
    } catch (e) {
      setError(e.response?.data?.detail || 'Failed to start capture')
    } finally { setLoading(false) }
  }

  const handleStop = async () => {
    setLoading(true); setError(null)
    try {
      await stopCapture()
      setRunning(false)
      onStatusChange?.('stopped')
    } catch (e) {
      setError(e.response?.data?.detail || 'Failed to stop capture')
    } finally { setLoading(false) }
  }

  return (
    <div style={{
      background: 'var(--bg2)', border: '1px solid var(--border)',
      borderRadius: 6, padding: '12px 14px', display: 'flex',
      flexWrap: 'wrap', gap: 10, alignItems: 'flex-end',
    }}>
      {/* Interface */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
        <label style={{ fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.07em' }}>
          Interface
        </label>
        <select
          value={iface}
          onChange={e => setIface(e.target.value)}
          disabled={running}
          style={selStyle}
        >
          {ifaces.map(i => <option key={i} value={i}>{i}</option>)}
          {!ifaces.length && <option value="eth0">eth0</option>}
        </select>
      </div>

      {/* BPF Filter */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 4, flex: 1, minWidth: 160 }}>
        <label style={{ fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.07em' }}>
          BPF Filter <span style={{ color: 'var(--muted)', fontWeight: 300 }}>(optional)</span>
        </label>
        <input
          value={filter}
          onChange={e => setFilter(e.target.value)}
          placeholder='e.g. tcp port 443'
          disabled={running}
          style={inputStyle}
        />
      </div>

      {/* Buttons */}
      <div style={{ display: 'flex', gap: 8 }}>
        {!running ? (
          <button onClick={handleStart} disabled={loading} style={btnStyle('var(--accent)')}>
            {loading ? <RefreshCw size={13} style={{ animation: 'spin 1s linear infinite' }} /> : <Play size={13} />}
            Start Capture
          </button>
        ) : (
          <button onClick={handleStop} disabled={loading} style={btnStyle('var(--danger)')}>
            {loading ? <RefreshCw size={13} style={{ animation: 'spin 1s linear infinite' }} /> : <Square size={13} />}
            Stop
          </button>
        )}
      </div>

      {/* Status / Error */}
      <div style={{ width: '100%', display: 'flex', alignItems: 'center', gap: 6 }}>
        <div style={{
          width: 7, height: 7, borderRadius: '50%',
          background: running ? 'var(--green)' : 'var(--muted)',
          boxShadow: running ? '0 0 6px var(--green)' : 'none',
          animation: running ? 'blink 2s infinite' : 'none',
        }} />
        <span style={{ fontFamily: 'var(--mono)', fontSize: 10, color: running ? 'var(--green)' : 'var(--muted)' }}>
          {running ? `Capturing on ${iface}${filter ? ` · filter: ${filter}` : ''}` : 'Idle — not capturing'}
        </span>
        {error && <span style={{ fontSize: 10, color: 'var(--danger)', marginLeft: 8 }}>{error}</span>}
      </div>
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  )
}

const selStyle = {
  background: 'var(--bg3)', border: '1px solid var(--border2)',
  color: 'var(--text)', fontFamily: 'var(--mono)', fontSize: 11,
  padding: '5px 8px', borderRadius: 4, cursor: 'pointer', minWidth: 110,
}
const inputStyle = {
  background: 'var(--bg3)', border: '1px solid var(--border2)',
  color: 'var(--text)', fontFamily: 'var(--mono)', fontSize: 11,
  padding: '5px 8px', borderRadius: 4, outline: 'none', width: '100%',
}
const btnStyle = (color) => ({
  display: 'flex', alignItems: 'center', gap: 6,
  padding: '5px 14px', borderRadius: 4, cursor: 'pointer',
  background: `${color}18`, border: `1px solid ${color}55`,
  color, fontFamily: 'var(--mono)', fontSize: 11,
  letterSpacing: '0.06em', transition: 'all 0.15s',
})
