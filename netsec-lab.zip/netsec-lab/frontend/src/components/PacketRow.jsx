import React from 'react'

const PROTO_COLORS = {
  TCP: '#00d4ff', UDP: '#00e676', DNS: '#b06afc',
  HTTP: '#ffa726', HTTPS: '#66bb6a', ICMP: '#ff4458',
  SSH: '#26c6da', ARP: '#8d6e63', FTP: '#ef5350',
  SMTP: '#ab47bc', TLS: '#66bb6a', OTHER: '#56627a',
}

function protocolColor(proto = 'OTHER') {
  return PROTO_COLORS[proto] || PROTO_COLORS.OTHER
}

export default function PacketRow({ pkt, style = {} }) {
  const color = protocolColor(pkt.protocol)
  const ts = pkt.timestamp
    ? new Date(pkt.timestamp).toLocaleTimeString([], { hour12: false })
    : '—'

  return (
    <tr style={{
      borderBottom: '0.5px solid rgba(255,255,255,0.04)',
      fontFamily: 'var(--mono)', fontSize: 10,
      ...style,
    }}>
      <td style={{ padding: '3px 8px', color: 'var(--muted)', whiteSpace: 'nowrap' }}>{ts}</td>
      <td style={{ padding: '3px 8px' }}>
        <span style={{
          display: 'inline-block', padding: '1px 5px',
          borderRadius: 3, fontSize: 9, fontWeight: 600,
          background: `${color}20`, color, border: `1px solid ${color}40`,
        }}>
          {pkt.protocol || '?'}
        </span>
      </td>
      <td style={{ padding: '3px 8px', color: 'var(--text)' }}>
        {pkt.src_ip || '—'}
        {pkt.src_port != null && <span style={{ color: 'var(--muted)' }}>:{pkt.src_port}</span>}
      </td>
      <td style={{ padding: '3px 4px', color: 'var(--muted)' }}>→</td>
      <td style={{ padding: '3px 8px', color: 'var(--text)' }}>
        {pkt.dst_ip || '—'}
        {pkt.dst_port != null && <span style={{ color: 'var(--muted)' }}>:{pkt.dst_port}</span>}
      </td>
      <td style={{ padding: '3px 8px', color: 'var(--muted)', textAlign: 'right' }}>
        {pkt.length ?? '—'}B
      </td>
      <td style={{ padding: '3px 8px', color: 'var(--warn)', fontSize: 9 }}>
        {pkt.flags || ''}
      </td>
      <td style={{ padding: '3px 8px', color: 'var(--muted)', maxWidth: 120, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
        {pkt.geo_src || pkt.geo_dst || ''}
      </td>
    </tr>
  )
}
