import React, { useState } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import {
  LayoutDashboard, Radio, ShieldAlert,
  BarChart2, Globe, Menu, X, Activity
} from 'lucide-react'

const NAV = [
  { to: '/',         icon: LayoutDashboard, label: 'Dashboard' },
  { to: '/packets',  icon: Radio,           label: 'Packets' },
  { to: '/alerts',   icon: ShieldAlert,     label: 'Alerts' },
  { to: '/analysis', icon: BarChart2,       label: 'Analysis' },
  { to: '/geo',      icon: Globe,           label: 'Geo Map' },
]

const s = {
  shell:   { display:'flex', height:'100vh', overflow:'hidden' },
  sidebar: (open) => ({
    width: open ? 200 : 56, flexShrink:0,
    background:'var(--bg1)', borderRight:'1px solid var(--border)',
    display:'flex', flexDirection:'column',
    transition:'width 0.2s ease', overflow:'hidden',
  }),
  sideTop: {
    height:42, display:'flex', alignItems:'center',
    borderBottom:'1px solid var(--border)', flexShrink:0, gap:10, padding:'0 14px',
  },
  logo: { display:'flex', alignItems:'center', gap:8, minWidth:0 },
  logoDot: {
    width:8, height:8, borderRadius:'50%', flexShrink:0,
    background:'var(--accent)', boxShadow:'0 0 8px var(--accent)',
  },
  logoText: {
    fontFamily:'var(--mono)', fontSize:11, letterSpacing:'0.1em',
    color:'var(--accent)', textTransform:'uppercase', whiteSpace:'nowrap',
  },
  toggleBtn: {
    marginLeft:'auto', background:'none', border:'none',
    color:'var(--muted)', cursor:'pointer', flexShrink:0,
    display:'flex', alignItems:'center', padding:2,
  },
  nav: { flex:1, padding:'8px 0', overflowY:'auto' },
  link: (active, open) => ({
    display:'flex', alignItems:'center', gap:10,
    padding: open ? '7px 14px' : '7px 16px',
    borderLeft:`2px solid ${active ? 'var(--accent)' : 'transparent'}`,
    background: active ? 'rgba(0,212,255,0.07)' : 'transparent',
    color: active ? 'var(--accent)' : 'var(--muted)',
    textDecoration:'none', fontSize:12, fontWeight:500,
    whiteSpace:'nowrap', overflow:'hidden',
    transition:'all 0.15s', cursor:'pointer',
  }),
  linkLabel: { overflow:'hidden', textOverflow:'ellipsis' },
  main: { flex:1, display:'flex', flexDirection:'column', overflow:'hidden' },
  topbar: {
    height:42, background:'var(--bg1)', borderBottom:'1px solid var(--border)',
    display:'flex', alignItems:'center', gap:12, padding:'0 16px', flexShrink:0,
  },
  pageTitle: { fontSize:13, fontWeight:600, color:'var(--text)' },
  connPill: (ok) => ({
    marginLeft:'auto', display:'flex', alignItems:'center', gap:5,
    fontFamily:'var(--mono)', fontSize:10, letterSpacing:'0.06em',
    padding:'3px 9px', borderRadius:3,
    background: ok ? 'rgba(0,230,118,0.08)' : 'rgba(255,68,88,0.08)',
    border:`1px solid ${ok ? 'rgba(0,230,118,0.25)' : 'rgba(255,68,88,0.25)'}`,
    color: ok ? 'var(--green)' : 'var(--danger)',
  }),
  pip: (ok) => ({
    width:5, height:5, borderRadius:'50%',
    background: ok ? 'var(--green)' : 'var(--danger)',
    animation: ok ? 'none' : 'blink 1s infinite',
  }),
  content: { flex:1, overflow:'auto', padding:16 },
}

export default function Layout({ children, connected, reconnecting }) {
  const [open, setOpen] = useState(true)
  const loc = useLocation()

  const currentPage = NAV.find(n => n.to === loc.pathname)?.label || 'NetSec Lab'

  return (
    <div style={s.shell}>
      <style>{`
        @keyframes blink { 0%,100%{opacity:1} 50%{opacity:0.25} }
        a:hover > * { color: var(--text) !important; }
      `}</style>

      {/* Sidebar */}
      <div style={s.sidebar(open)}>
        <div style={s.sideTop}>
          <div style={s.logo}>
            <div style={s.logoDot} />
            {open && <span style={s.logoText}>NetSec Lab</span>}
          </div>
          <button style={s.toggleBtn} onClick={() => setOpen(o => !o)}>
            {open ? <X size={14} /> : <Menu size={14} />}
          </button>
        </div>

        <nav style={s.nav}>
          {NAV.map(({ to, icon: Icon, label }) => {
            const active = loc.pathname === to
            return (
              <NavLink key={to} to={to} style={s.link(active, open)}>
                <Icon size={15} strokeWidth={1.8} style={{ flexShrink: 0 }} />
                {open && <span style={s.linkLabel}>{label}</span>}
              </NavLink>
            )
          })}
        </nav>

        {open && (
          <div style={{
            padding:'10px 14px', borderTop:'1px solid var(--border)',
            fontFamily:'var(--mono)', fontSize:9, color:'var(--muted)',
            letterSpacing:'0.08em',
          }}>
            v1.0.0 — WSL2
          </div>
        )}
      </div>

      {/* Main area */}
      <div style={s.main}>
        <div style={s.topbar}>
          <Activity size={14} color="var(--accent)" />
          <span style={s.pageTitle}>{currentPage}</span>
          <div style={s.connPill(connected)}>
            <div style={s.pip(connected)} />
            {reconnecting ? 'Reconnecting…' : connected ? 'Live' : 'Disconnected'}
          </div>
        </div>
        <div style={s.content}>{children}</div>
      </div>
    </div>
  )
}
