import React from 'react'
import {
  AreaChart, Area, XAxis, YAxis, Tooltip,
  ResponsiveContainer, CartesianGrid
} from 'recharts'

const CustomTooltip = ({ active, payload, label, unit }) => {
  if (!active || !payload?.length) return null
  return (
    <div style={{
      background: 'var(--bg3)', border: '1px solid var(--border2)',
      borderRadius: 4, padding: '6px 10px',
      fontFamily: 'var(--mono)', fontSize: 11,
    }}>
      <div style={{ color: 'var(--muted)', marginBottom: 2 }}>
        {new Date(label * 1000).toLocaleTimeString()}
      </div>
      <div style={{ color: 'var(--accent)' }}>
        {payload[0].value} {unit}
      </div>
    </div>
  )
}

export default function LiveChart({ data = [], color = 'var(--accent)', unit = 'pps', title }) {
  return (
    <div style={{
      background: 'var(--bg2)', border: '1px solid var(--border)',
      borderRadius: 6, padding: '12px 14px',
    }}>
      {title && (
        <div style={{
          fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase',
          letterSpacing: '0.08em', marginBottom: 10,
        }}>
          {title}
        </div>
      )}
      <ResponsiveContainer width="100%" height={120}>
        <AreaChart data={data} margin={{ top: 4, right: 4, left: -20, bottom: 0 }}>
          <defs>
            <linearGradient id={`grad-${unit}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%"  stopColor={color} stopOpacity={0.25} />
              <stop offset="95%" stopColor={color} stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 8" stroke="rgba(255,255,255,0.04)" />
          <XAxis
            dataKey="ts"
            tickFormatter={ts => new Date(ts * 1000).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            tick={{ fontFamily: 'var(--mono)', fontSize: 9, fill: 'var(--muted)' }}
            tickLine={false} axisLine={false}
            minTickGap={40}
          />
          <YAxis
            tick={{ fontFamily: 'var(--mono)', fontSize: 9, fill: 'var(--muted)' }}
            tickLine={false} axisLine={false}
          />
          <Tooltip content={<CustomTooltip unit={unit} />} />
          <Area
            type="monotone" dataKey="value"
            stroke={color} strokeWidth={1.5}
            fill={`url(#grad-${unit})`}
            dot={false} isAnimationActive={false}
          />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  )
}
