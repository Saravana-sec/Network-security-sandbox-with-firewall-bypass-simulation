import React from 'react'

const SEV_MAP = {
  1: { label: 'HIGH',   color: '#ff4458' },
  2: { label: 'MEDIUM', color: '#ffa726' },
  3: { label: 'LOW',    color: '#00e676' },
}

const ETYPE_COLORS = {
  alert: '#ff4458', dns: '#b06afc', http: '#ffa726',
  tls: '#00e676', flow: '#00d4ff', stats: '#56627a',
}

export default function AlertRow({ alert, onClick }) {
  const sev   = SEV_MAP[alert.severity] || { label: '—', color: 'var(--muted)' }
  const color = ETYPE_COLORS[alert.event_type] || 'var(--muted)'
  const ts    = alert.timestamp
    ? new Date(alert.timestamp).toLocaleTimeString([], { hour12: false })
    : '—'

  return (
    <tr
      onClick={() => onClick?.(alert)}
      style={{
        borderBottom: '0.5px solid rgba(255,255,255,0.04)',
        fontFamily: 'var(--mono)', fontSize: 10,
        cursor: onClick ? 'pointer' : 'default',
      }}
    >
      <td style={{ padding: '4px 8px', color: 'var(--muted)', whiteSpace: 'nowrap' }}>{ts}</td>
      <td style={{ padding: '4px 8px' }}>
        <span style={{
          display: 'inline-block', padding: '1px 5px', borderRadius: 3, fontSize: 9,
          background: `${color}18`, color, border: `1px solid ${color}40`,
        }}>
          {alert.event_type?.toUpperCase() || '?'}
        </span>
      </td>
      <td style={{ padding: '4px 8px' }}>
        {alert.severity != null && (
          <span style={{
            display: 'inline-block', padding: '1px 5px', borderRadius: 3, fontSize: 9,
            background: `${sev.color}18`, color: sev.color, border: `1px solid ${sev.color}40`,
          }}>
            {sev.label}
          </span>
        )}
      </td>
      <td style={{
        padding: '4px 8px', color: 'var(--text)',
        maxWidth: 280, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap',
      }}>
        {alert.signature || alert.dns_query || alert.http_host || alert.tls_sni || '—'}
      </td>
      <td style={{ padding: '4px 8px', color: 'var(--text)' }}>{alert.src_ip || '—'}</td>
      <td style={{ padding: '4px 4px', color: 'var(--muted)' }}>→</td>
      <td style={{ padding: '4px 8px', color: 'var(--text)' }}>{alert.dst_ip || '—'}</td>
      <td style={{ padding: '4px 8px', color: 'var(--muted)' }}>{alert.protocol || '—'}</td>
    </tr>
  )
}
