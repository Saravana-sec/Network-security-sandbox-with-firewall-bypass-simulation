import React from 'react'

export default function StatCard({ label, value, unit = '', color = 'var(--accent)', icon: Icon, sub }) {
  return (
    <div style={{
      background: 'var(--bg2)',
      border: '1px solid var(--border)',
      borderRadius: 6,
      padding: '12px 14px',
      display: 'flex',
      flexDirection: 'column',
      gap: 4,
      minWidth: 0,
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
        {Icon && <Icon size={13} color="var(--muted)" strokeWidth={1.8} />}
        <span style={{ fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.07em' }}>
          {label}
        </span>
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 4 }}>
        <span style={{ fontFamily: 'var(--mono)', fontSize: 24, fontWeight: 600, color, lineHeight: 1 }}>
          {value ?? '—'}
        </span>
        {unit && <span style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--muted)' }}>{unit}</span>}
      </div>
      {sub && <div style={{ fontSize: 10, color: 'var(--muted)' }}>{sub}</div>}
    </div>
  )
}
