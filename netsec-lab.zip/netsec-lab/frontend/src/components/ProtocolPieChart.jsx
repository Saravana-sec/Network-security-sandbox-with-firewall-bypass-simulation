import React from 'react'
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend } from 'recharts'

const COLORS = [
  '#00d4ff','#00e676','#ffa726','#ff4458','#b06afc',
  '#26c6da','#66bb6a','#ef5350','#ab47bc','#8d6e63',
]

const CustomTooltip = ({ active, payload }) => {
  if (!active || !payload?.length) return null
  const d = payload[0]
  return (
    <div style={{
      background: 'var(--bg3)', border: '1px solid var(--border2)',
      borderRadius: 4, padding: '6px 10px',
      fontFamily: 'var(--mono)', fontSize: 11,
    }}>
      <span style={{ color: d.payload.fill }}>{d.name}</span>
      <span style={{ color: 'var(--text)', marginLeft: 8 }}>{d.value.toLocaleString()}</span>
      <span style={{ color: 'var(--muted)', marginLeft: 4 }}>pkts</span>
    </div>
  )
}

export default function ProtocolPieChart({ data = [] }) {
  if (!data.length) return (
    <div style={emptyStyle}>No protocol data yet</div>
  )
  const chartData = data.slice(0, 10).map((d, i) => ({
    name: d.protocol,
    value: d.count,
    fill: COLORS[i % COLORS.length],
  }))

  return (
    <div style={{
      background: 'var(--bg2)', border: '1px solid var(--border)',
      borderRadius: 6, padding: '12px 14px',
    }}>
      <div style={{ fontSize: 10, color: 'var(--muted)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 10 }}>
        Protocol Breakdown
      </div>
      <ResponsiveContainer width="100%" height={200}>
        <PieChart>
          <Pie
            data={chartData} dataKey="value" nameKey="name"
            cx="50%" cy="50%" innerRadius={50} outerRadius={80}
            strokeWidth={0} isAnimationActive={false}
          >
            {chartData.map((entry, i) => (
              <Cell key={i} fill={entry.fill} />
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip />} />
          <Legend
            iconType="circle" iconSize={7}
            formatter={(v) => <span style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--text)' }}>{v}</span>}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  )
}

const emptyStyle = {
  background: 'var(--bg2)', border: '1px solid var(--border)',
  borderRadius: 6, padding: '40px 14px',
  textAlign: 'center', color: 'var(--muted)', fontSize: 12,
}
