import axios from 'axios'

const api = axios.create({
  baseURL: '',
  timeout: 10000,
})

// ── Capture ────────────────────────────────────────────────────────
export const getInterfaces  = ()         => api.get('/capture/interfaces')
export const startCapture   = (payload)  => api.post('/capture/start', payload)
export const stopCapture    = ()         => api.post('/capture/stop')
export const getCaptureStatus = ()       => api.get('/capture/status')

// ── Alerts ────────────────────────────────────────────────────────
export const getAlerts      = (params)   => api.get('/alerts/', { params })
export const getAlertsSummary = ()       => api.get('/alerts/summary')
export const getAlert       = (id)       => api.get(`/alerts/${id}`)

// ── Analysis ──────────────────────────────────────────────────────
export const getStats       = ()         => api.get('/analysis/stats')
export const getTimeseries  = (params)   => api.get('/analysis/timeseries', { params })
export const getProtocols   = ()         => api.get('/analysis/protocols')
export const getTopTalkers  = ()         => api.get('/analysis/top-talkers')
export const getDNS         = ()         => api.get('/analysis/dns')
export const getHTTP        = ()         => api.get('/analysis/http')

export default api
